export interface CodeFile {
  path: string;
  language: string;
  description: string;
  content: string;
}

export const PHP_PROJECT_FILES: CodeFile[] = [
  {
    path: 'database/tutorconnect.sql',
    language: 'sql',
    description: 'MySQL Database Schema & Initial Seed Data',
    content: `-- TutorConnect Database Schema
-- Run this in phpMyAdmin or via MySQL CLI

CREATE DATABASE IF NOT EXISTS \`tutorconnect\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE \`tutorconnect\`;

-- 1. Users Table (Core authentication for Student, Teacher, Admin)
CREATE TABLE IF NOT EXISTS \`users\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(100) NOT NULL,
  \`email\` VARCHAR(150) NOT NULL UNIQUE,
  \`password\` VARCHAR(255) NOT NULL,
  \`role\` ENUM('student', 'teacher', 'admin') NOT NULL DEFAULT 'student',
  \`phone\` VARCHAR(20) NOT NULL,
  \`avatar_url\` VARCHAR(255) DEFAULT 'default-avatar.png',
  \`is_blocked\` TINYINT(1) DEFAULT 0,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Teachers Profile Table
CREATE TABLE IF NOT EXISTS \`teachers\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NOT NULL,
  \`qualification\` VARCHAR(200) NOT NULL,
  \`experience\` INT NOT NULL DEFAULT 1,
  \`subjects\` TEXT NOT NULL, -- comma separated e.g. "Mathematics, Physics"
  \`classes\` TEXT NOT NULL,  -- comma separated e.g. "Class 9-10, Class 11-12"
  \`location\` VARCHAR(200) NOT NULL,
  \`city\` VARCHAR(100) NOT NULL,
  \`hourly_fee\` INT NOT NULL DEFAULT 500,
  \`monthly_fee\` INT NOT NULL DEFAULT 4000,
  \`teaching_mode\` ENUM('online', 'offline', 'both') NOT NULL DEFAULT 'both',
  \`available_timings\` TEXT NOT NULL,
  \`about\` TEXT NOT NULL,
  \`verification_status\` ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
  \`verification_notes\` TEXT DEFAULT NULL,
  \`degree_document\` VARCHAR(255) DEFAULT NULL,
  \`rating\` DECIMAL(3,2) DEFAULT 5.00,
  \`review_count\` INT DEFAULT 0,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 3. Students Profile Table
CREATE TABLE IF NOT EXISTS \`students\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT NOT NULL,
  \`grade_class\` VARCHAR(100) NOT NULL,
  \`target_subjects\` TEXT NOT NULL,
  \`location\` VARCHAR(200) NOT NULL,
  \`city\` VARCHAR(100) NOT NULL,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Tuition Requests Table
CREATE TABLE IF NOT EXISTS \`tuition_requests\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`student_id\` INT NOT NULL,
  \`teacher_id\` INT NOT NULL,
  \`subject\` VARCHAR(100) NOT NULL,
  \`teaching_mode\` ENUM('online', 'offline', 'both') NOT NULL,
  \`preferred_timings\` VARCHAR(200) NOT NULL,
  \`message\` TEXT NOT NULL,
  \`status\` ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
  \`teacher_reply\` TEXT DEFAULT NULL,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`student_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`teacher_id\`) REFERENCES \`teachers\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Seed Default Admin User (Password is: admin123)
-- Hash generated via password_hash('admin123', PASSWORD_BCRYPT)
INSERT INTO \`users\` (\`name\`, \`email\`, \`password\`, \`role\`, \`phone\`, \`is_blocked\`)
VALUES ('System Admin', 'admin@tutorconnect.com', '$2y$10$wO8lK88u9E0r0VkWJ3jQce71V/mG4Wf9z8j37YyKj/K7J6h4Y5Z1e', 'admin', '+91 99999 11111', 0)
ON DUPLICATE KEY UPDATE \`email\`=\`email\`;
`
  },
  {
    path: 'config/db.php',
    language: 'php',
    description: 'PDO Database Connection Configuration for XAMPP',
    content: `<?php
// config/db.php
// Default XAMPP MySQL credentials
$host     = '127.0.0.1';
$db       = 'tutorconnect';
$user     = 'root';
$password = ''; // XAMPP default root password is empty
$charset  = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $password, $options);
} catch (\PDOException $e) {
    die("Database connection failed. Please ensure MySQL is running in XAMPP and 'tutorconnect' database is created. Error: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>`
  },
  {
    path: 'auth/login.php',
    language: 'php',
    description: 'Secure Multi-Role Login Handler with Password Verification',
    content: `<?php
// auth/login.php
require_once __DIR__ . '/../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['is_blocked'] == 1) {
                $error = "Your account has been suspended by the administrator.";
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];

                // Role based redirect
                if ($user['role'] === 'admin') {
                    header("Location: ../admin/dashboard.php");
                } elseif ($user['role'] === 'teacher') {
                    header("Location: ../teacher/dashboard.php");
                } else {
                    header("Location: ../student/dashboard.php");
                }
                exit;
            }
        } else {
            $error = "Invalid email or password.";
        }
    }
}
?>
<!-- Include standard HTML login template -->`
  },
  {
    path: 'auth/register.php',
    language: 'php',
    description: 'Registration for Student and Teacher with profile provisioning',
    content: `<?php
// auth/register.php
require_once __DIR__ . '/../config/db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $phone    = trim($_POST['phone'] ?? '');
    $role     = $_POST['role'] ?? 'student'; // 'student' or 'teacher'

    if (empty($name) || empty($email) || empty($password) || empty($phone)) {
        $error = "All mandatory fields are required.";
    } else {
        // Check existing email
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->rowCount() > 0) {
            $error = "An account with this email already exists.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $pdo->beginTransaction();

            try {
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, phone) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $email, $hashedPassword, $role, $phone]);
                $userId = $pdo->lastInsertId();

                if ($role === 'teacher') {
                    $qualification = $_POST['qualification'] ?? 'Degree Pending';
                    $experience    = intval($_POST['experience'] ?? 1);
                    $subjects      = $_POST['subjects'] ?? 'General';
                    $classes       = $_POST['classes'] ?? 'Class 6-10';
                    $location      = $_POST['location'] ?? 'City Center';
                    $city          = $_POST['city'] ?? 'Metro';
                    $hourly_fee    = intval($_POST['hourly_fee'] ?? 500);
                    $teaching_mode = $_POST['teaching_mode'] ?? 'both';
                    $about         = $_POST['about'] ?? 'Dedicated educator.';

                    $tStmt = $pdo->prepare("INSERT INTO teachers 
                        (user_id, qualification, experience, subjects, classes, location, city, hourly_fee, teaching_mode, available_timings, about, verification_status) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Flexible Evenings', ?, 'pending')");
                    $tStmt->execute([$userId, $qualification, $experience, $subjects, $classes, $location, $city, $hourly_fee, $teaching_mode, $about]);
                } else {
                    $grade_class     = $_POST['grade_class'] ?? 'Class 10';
                    $target_subjects = $_POST['target_subjects'] ?? 'Mathematics, Science';
                    $location        = $_POST['location'] ?? 'City';
                    $city            = $_POST['city'] ?? 'Metro';

                    $sStmt = $pdo->prepare("INSERT INTO students (user_id, grade_class, target_subjects, location, city) VALUES (?, ?, ?, ?, ?)");
                    $sStmt->execute([$userId, $grade_class, $target_subjects, $location, $city]);
                }

                $pdo->commit();
                header("Location: login.php?registered=1");
                exit;
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = "Registration failed: " . $e->getMessage();
            }
        }
    }
}
?>`
  },
  {
    path: 'student/search.php',
    language: 'php',
    description: 'Dynamic Search & Filter API / Page for Finding Teachers',
    content: `<?php
// student/search.php
require_once __DIR__ . '/../config/db.php';

$subject      = trim($_GET['subject'] ?? '');
$classGrade   = trim($_GET['class'] ?? '');
$location     = trim($_GET['location'] ?? '');
$mode         = trim($_GET['mode'] ?? '');
$maxFee       = intval($_GET['max_fee'] ?? 0);
$verifiedOnly = isset($_GET['verified_only']) && $_GET['verified_only'] == '1';

$sql = "SELECT t.*, u.name, u.email, u.phone, u.avatar_url, u.is_blocked 
        FROM teachers t 
        JOIN users u ON t.user_id = u.id 
        WHERE u.is_blocked = 0";
$params = [];

if (!empty($subject)) {
    $sql .= " AND t.subjects LIKE ?";
    $params[] = "%$subject%";
}
if (!empty($classGrade)) {
    $sql .= " AND t.classes LIKE ?";
    $params[] = "%$classGrade%";
}
if (!empty($location)) {
    $sql .= " AND (t.location LIKE ? OR t.city LIKE ?)";
    $params[] = "%$location%";
    $params[] = "%$location%";
}
if (!empty($mode) && $mode !== 'all') {
    $sql .= " AND (t.teaching_mode = ? OR t.teaching_mode = 'both')";
    $params[] = $mode;
}
if ($maxFee > 0) {
    $sql .= " AND t.hourly_fee <= ?";
    $params[] = $maxFee;
}
if ($verifiedOnly) {
    $sql .= " AND t.verification_status = 'verified'";
}

$sql .= " ORDER BY (t.verification_status = 'verified') DESC, t.rating DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$teachers = $stmt->fetchAll();
// Returns matching teachers with verified badges
?>`
  },
  {
    path: 'student/send_request.php',
    language: 'php',
    description: 'Handles Sending Tuition Requests from Student to Teacher',
    content: `<?php
// student/send_request.php
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../auth/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId   = $_SESSION['user_id'];
    $teacherId   = intval($_POST['teacher_id']);
    $subject     = trim($_POST['subject']);
    $mode        = $_POST['teaching_mode'] ?? 'online';
    $timings     = trim($_POST['preferred_timings']);
    $message     = trim($_POST['message']);

    $stmt = $pdo->prepare("INSERT INTO tuition_requests 
        (student_id, teacher_id, subject, teaching_mode, preferred_timings, message, status) 
        VALUES (?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->execute([$studentId, $teacherId, $subject, $mode, $timings, $message]);

    header("Location: dashboard.php?msg=request_sent");
    exit;
}
?>`
  },
  {
    path: 'teacher/dashboard.php',
    language: 'php',
    description: 'Teacher Dashboard with Request Management & Verification Status',
    content: `<?php
// teacher/dashboard.php
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: ../auth/login.php");
    exit;
}

$userId = $_SESSION['user_id'];

// Get Teacher Profile
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$userId]);
$teacher = $stmt->fetch();

if (!$teacher) {
    die("Teacher profile not found.");
}

// Handle Accept/Reject action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_request'])) {
    $reqId = intval($_POST['request_id']);
    $action = $_POST['action'] === 'accepted' ? 'accepted' : 'rejected';
    $reply = trim($_POST['reply_note'] ?? '');

    $upd = $pdo->prepare("UPDATE tuition_requests SET status = ?, teacher_reply = ? WHERE id = ? AND teacher_id = ?");
    $upd->execute([$action, $reply, $reqId, $teacher['id']]);
    header("Location: dashboard.php?updated=1");
    exit;
}

// Fetch Incoming Requests
$rStmt = $pdo->prepare("SELECT tr.*, u.name AS student_name, u.email AS student_email, u.phone AS student_phone 
                        FROM tuition_requests tr 
                        JOIN users u ON tr.student_id = u.id 
                        WHERE tr.teacher_id = ? 
                        ORDER BY tr.created_at DESC");
$rStmt->execute([$teacher['id']]);
$requests = $rStmt->fetchAll();
?>`
  },
  {
    path: 'admin/dashboard.php',
    language: 'php',
    description: 'Admin Control Panel for Verification, Blocking, and Requests Audit',
    content: `<?php
// admin/dashboard.php
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Handle Approve / Reject Teacher Verification
if (isset($_POST['verify_action'])) {
    $teacherId = intval($_POST['teacher_id']);
    $newStatus = $_POST['status'] === 'verified' ? 'verified' : 'rejected';
    $notes = trim($_POST['notes'] ?? '');

    $stmt = $pdo->prepare("UPDATE teachers SET verification_status = ?, verification_notes = ? WHERE id = ?");
    $stmt->execute([$newStatus, $notes, $teacherId]);
    header("Location: dashboard.php?verified=1");
    exit;
}

// Handle Block / Unblock User
if (isset($_POST['toggle_block'])) {
    $targetUserId = intval($_POST['user_id']);
    $blockVal = intval($_POST['block_val']); // 0 or 1

    $stmt = $pdo->prepare("UPDATE users SET is_blocked = ? WHERE id = ? AND role != 'admin'");
    $stmt->execute([$blockVal, $targetUserId]);
    header("Location: dashboard.php?block_updated=1");
    exit;
}

// Stats
$totalStudents = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$totalTeachers = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'teacher'")->fetchColumn();
$pendingVerifications = $pdo->query("SELECT COUNT(*) FROM teachers WHERE verification_status = 'pending'")->fetchColumn();
$totalRequests = $pdo->query("SELECT COUNT(*) FROM tuition_requests")->fetchColumn();

// Fetch Pending Teachers
$pendingTeachers = $pdo->query("SELECT t.*, u.name, u.email, u.phone FROM teachers t JOIN users u ON t.user_id = u.id WHERE t.verification_status = 'pending'")->fetchAll();

// Fetch All Users
$allUsers = $pdo->query("SELECT * FROM users WHERE role != 'admin' ORDER BY created_at DESC")->fetchAll();
?>`
  }
];

export const XAMPP_INSTRUCTIONS = `
# How to Run TutorConnect on XAMPP (Apache + PHP + MySQL)

### Step 1: Install & Launch XAMPP
1. Download and install **XAMPP** from [apachefriends.org](https://www.apachefriends.org/) (PHP 8.0+ recommended).
2. Open the **XAMPP Control Panel**.
3. Click **Start** for both **Apache** and **MySQL**. Both should show green active indicators.

### Step 2: Create the Database in phpMyAdmin
1. Open your browser and navigate to: \`http://localhost/phpmyadmin\`
2. Click on the **Databases** tab at the top.
3. Enter database name: \`tutorconnect\` and choose collation: \`utf8mb4_unicode_ci\`.
4. Click **Create**.

### Step 3: Import the SQL Schema
1. Select the newly created \`tutorconnect\` database from the left sidebar.
2. Click on the **Import** tab.
3. Choose the \`database/tutorconnect.sql\` file provided in this package (or copy-paste the SQL into the **SQL** tab).
4. Click **Go** / **Execute**.
5. All 4 tables (\`users\`, \`teachers\`, \`students\`, \`tuition_requests\`) will be created and seeded with default administrator credentials.

### Step 4: Place Files in XAMPP htdocs
1. Navigate to your XAMPP installation directory:
   - **Windows:** \`C:\\xampp\\htdocs\\tutorconnect\`
   - **macOS:** \`/Applications/XAMPP/xamppfiles/htdocs/tutorconnect\`
   - **Linux:** \`/opt/lampp/htdocs/tutorconnect\`
2. Copy all project PHP files, folders (\`auth\`, \`config\`, \`student\`, \`teacher\`, \`admin\`), assets, and CSS into this folder.

### Step 5: Test the Website
1. Open your web browser and visit:
   \`http://localhost/tutorconnect/\`
2. **Default Admin Login Credentials:**
   - **Email:** \`admin@tutorconnect.com\`
   - **Password:** \`admin123\`
3. You can register new Students and Teachers to test the full lifecycle:
   - Register a Teacher -> appears in Admin Verification Queue -> Admin Approves -> Teacher receives **Verified Badge** -> Student searches and sends a Tuition Request -> Teacher accepts -> Contact details exchanged!
`;
