import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  TeacherProfile,
  StudentProfile,
  TuitionRequest,
  UserRole,
  VerificationStatus,
  RequestStatus,
  TeachingMode
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_TEACHERS,
  INITIAL_STUDENTS,
  INITIAL_REQUESTS
} from '../data/mockData';
import { DEFAULT_ANIMATED_STUDENT_AVATAR } from '../components/AnimatedStudentAvatar';

interface AuthContextType {
  currentUser: User | null;
  currentTeacherProfile: TeacherProfile | null;
  currentStudentProfile: StudentProfile | null;
  allUsers: User[];
  allTeachers: TeacherProfile[];
  allStudents: StudentProfile[];
  allRequests: TuitionRequest[];
  login: (email: string, password?: string, role?: UserRole) => { success: boolean; error?: string };
  register: (
    user: { name: string; email: string; phone: string; role: UserRole; avatarUrl?: string },
    profileDetails: any
  ) => { success: boolean; error?: string };
  logout: () => void;
  switchDemoUser: (persona: 'admin' | 'teacher-verified' | 'teacher-pending' | 'student-1' | 'student-2') => void;
  sendTuitionRequest: (data: {
    teacherId: string;
    teacherName: string;
    teacherAvatar: string;
    subject: string;
    teachingMode: TeachingMode;
    preferredTimings: string;
    studentMessage: string;
  }) => { success: boolean; error?: string };
  respondToTuitionRequest: (requestId: string, status: RequestStatus, note?: string) => void;
  verifyTeacher: (teacherId: string, status: VerificationStatus, notes?: string) => void;
  toggleBlockUser: (userId: string) => void;
  updateTeacherProfile: (updatedData: Partial<TeacherProfile>) => void;
  updateStudentProfile: (updatedData: Partial<StudentProfile>) => void;
  resetAllData: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'tutorconnect_v5_';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load state from localStorage or initial mock data
  const [allUsers, setAllUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [allTeachers, setAllTeachers] = useState<TeacherProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'teachers');
    return saved ? JSON.parse(saved) : INITIAL_TEACHERS;
  });

  const [allStudents, setAllStudents] = useState<StudentProfile[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [allRequests, setAllRequests] = useState<TuitionRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'requests');
    return saved ? JSON.parse(saved) : INITIAL_REQUESTS;
  });

  // Current logged in user
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'current_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    // Default to student Aarav Patel so visitors immediately experience the platform
    return INITIAL_USERS.find(u => u.id === 'user-stud-1') || null;
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'users', JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'teachers', JSON.stringify(allTeachers));
  }, [allTeachers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'students', JSON.stringify(allStudents));
  }, [allStudents]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'requests', JSON.stringify(allRequests));
  }, [allRequests]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(STORAGE_KEY_PREFIX + 'current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(STORAGE_KEY_PREFIX + 'current_user');
    }
  }, [currentUser]);

  // Derived current profiles
  const currentTeacherProfile = React.useMemo(() => {
    if (!currentUser || currentUser.role !== 'teacher') return null;
    return allTeachers.find(t => t.userId === currentUser.id || t.email === currentUser.email) || null;
  }, [currentUser, allTeachers]);

  const currentStudentProfile = React.useMemo(() => {
    if (!currentUser || currentUser.role !== 'student') return null;
    return allStudents.find(s => s.userId === currentUser.id || s.email === currentUser.email) || null;
  }, [currentUser, allStudents]);

  // Login handler
  const login = (email: string, password = '', expectedRole?: UserRole) => {
    const normalizedEmail = email.trim().toLowerCase();
    
    // Check admin credentials
    if (normalizedEmail === 'admin@tutorconnect.com') {
      if (password && password !== 'admin123' && password !== 'admin') {
        return { success: false, error: 'Incorrect admin password. (Default is: admin123)' };
      }
      const admin = allUsers.find(u => u.role === 'admin') || INITIAL_USERS[0];
      setCurrentUser(admin);
      return { success: true };
    }

    const foundUser = allUsers.find(u => u.email.toLowerCase() === normalizedEmail);

    if (!foundUser) {
      return { success: false, error: 'No user account found with this email address.' };
    }

    if (foundUser.isBlocked) {
      return { success: false, error: 'This account has been suspended by the administrator.' };
    }

    if (expectedRole && foundUser.role !== expectedRole) {
      return { 
        success: false, 
        error: `This account is registered as a ${foundUser.role}. Please log in via the ${foundUser.role} portal.` 
      };
    }

    setCurrentUser(foundUser);
    return { success: true };
  };

  // Register handler
  const register = (
    userData: { name: string; email: string; phone: string; role: UserRole; avatarUrl?: string },
    profileDetails: any
  ) => {
    const normalizedEmail = userData.email.trim().toLowerCase();

    if (allUsers.some(u => u.email.toLowerCase() === normalizedEmail)) {
      return { success: false, error: 'An account with this email already exists.' };
    }

    const newUserId = `user-${Date.now()}`;
    const newUser: User = {
      id: newUserId,
      name: userData.name.trim(),
      email: normalizedEmail,
      phone: userData.phone.trim(),
      role: userData.role,
      avatarUrl: userData.avatarUrl || (userData.role === 'teacher'
        ? 'https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=400&auto=format&fit=crop&q=80'
        : DEFAULT_ANIMATED_STUDENT_AVATAR),
      isBlocked: false,
      createdAt: new Date().toISOString().split('T')[0]
    };

    setAllUsers(prev => [newUser, ...prev]);

    if (userData.role === 'teacher') {
      const newTeacher: TeacherProfile = {
        id: `t-${Date.now()}`,
        userId: newUserId,
        name: userData.name.trim(),
        email: normalizedEmail,
        phone: userData.phone.trim(),
        avatarUrl: newUser.avatarUrl!,
        qualification: profileDetails.qualification || 'Bachelor Degree',
        experience: Number(profileDetails.experience) || 1,
        subjects: Array.isArray(profileDetails.subjects) 
          ? profileDetails.subjects 
          : (profileDetails.subjects || 'General Subjects').split(',').map((s: string) => s.trim()),
        classes: Array.isArray(profileDetails.classes) 
          ? profileDetails.classes 
          : (profileDetails.classes || 'Class 6-10').split(',').map((c: string) => c.trim()),
        location: profileDetails.location || 'City Center',
        city: profileDetails.city || 'Metro',
        hourlyFee: Number(profileDetails.hourlyFee) || 500,
        monthlyFee: Number(profileDetails.monthlyFee) || (Number(profileDetails.hourlyFee || 500) * 8),
        teachingMode: profileDetails.teachingMode || 'both',
        availableTimings: Array.isArray(profileDetails.availableTimings) 
          ? profileDetails.availableTimings 
          : [profileDetails.availableTimings || 'Weekday Evenings (5:00 PM - 8:00 PM)'],
        about: profileDetails.about || 'Passionate educator committed to student success.',
        rating: 5.0,
        reviewCount: 0,
        verificationStatus: 'pending', // Requires admin approval
        verificationNotes: 'Pending document verification by Admin',
        degreesDocuments: profileDetails.degreesDocuments || 'Degree_Certificate_Submitted.pdf',
        isBlocked: false,
        joinedDate: new Date().toISOString().split('T')[0]
      };
      setAllTeachers(prev => [newTeacher, ...prev]);
    } else if (userData.role === 'student') {
      const newStudent: StudentProfile = {
        id: `s-${Date.now()}`,
        userId: newUserId,
        name: userData.name.trim(),
        email: normalizedEmail,
        phone: userData.phone.trim(),
        avatarUrl: newUser.avatarUrl!,
        gradeClass: profileDetails.gradeClass || 'Class 10',
        targetSubjects: Array.isArray(profileDetails.targetSubjects)
          ? profileDetails.targetSubjects
          : (profileDetails.targetSubjects || 'Mathematics, Science').split(',').map((s: string) => s.trim()),
        location: profileDetails.location || 'Metro Area',
        city: profileDetails.city || 'Metro',
        isBlocked: false,
        joinedDate: new Date().toISOString().split('T')[0]
      };
      setAllStudents(prev => [newStudent, ...prev]);
    }

    setCurrentUser(newUser);
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const switchDemoUser = (persona: 'admin' | 'teacher-verified' | 'teacher-pending' | 'student-1' | 'student-2') => {
    if (persona === 'admin') {
      const admin = allUsers.find(u => u.role === 'admin') || INITIAL_USERS[0];
      setCurrentUser(admin);
    } else if (persona === 'teacher-verified') {
      const teacher = allUsers.find(u => u.email === 'sunita.kulkarni@example.com') || INITIAL_USERS[1];
      setCurrentUser(teacher);
    } else if (persona === 'teacher-pending') {
      const teacher = allUsers.find(u => u.email === 'pooja.iyer@example.com') || INITIAL_USERS[5];
      setCurrentUser(teacher);
    } else if (persona === 'student-1') {
      const student = allUsers.find(u => u.email === 'aarav.patel@student.com') || INITIAL_USERS[6];
      setCurrentUser(student);
    } else if (persona === 'student-2') {
      const student = allUsers.find(u => u.email === 'sneha.roy@student.com') || INITIAL_USERS[7];
      setCurrentUser(student);
    }
  };

  const sendTuitionRequest = (data: {
    teacherId: string;
    teacherName: string;
    teacherAvatar: string;
    subject: string;
    teachingMode: TeachingMode;
    preferredTimings: string;
    studentMessage: string;
  }) => {
    if (!currentUser || currentUser.role !== 'student') {
      return { success: false, error: 'Please log in as a Student to send tuition requests.' };
    }

    const studentProfile = currentStudentProfile;
    const newRequest: TuitionRequest = {
      id: `req-${Date.now()}`,
      studentId: studentProfile ? studentProfile.id : currentUser.id,
      studentName: currentUser.name,
      studentEmail: currentUser.email,
      studentPhone: currentUser.phone,
      studentLocation: studentProfile ? studentProfile.location : 'Online / Local',
      studentClass: studentProfile ? studentProfile.gradeClass : 'High School',
      teacherId: data.teacherId,
      teacherName: data.teacherName,
      teacherAvatar: data.teacherAvatar,
      subject: data.subject,
      teachingMode: data.teachingMode,
      preferredTimings: data.preferredTimings,
      studentMessage: data.studentMessage,
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0]
    };

    setAllRequests(prev => [newRequest, ...prev]);
    return { success: true };
  };

  const respondToTuitionRequest = (requestId: string, status: RequestStatus, note?: string) => {
    setAllRequests(prev =>
      prev.map(req => {
        if (req.id === requestId) {
          return {
            ...req,
            status,
            teacherResponseNote: note || (status === 'accepted' ? 'Tuition request accepted! I will contact you to finalize timing.' : 'Sorry, my current batch is full.'),
            updatedAt: new Date().toISOString().split('T')[0]
          };
        }
        return req;
      })
    );
  };

  const verifyTeacher = (teacherId: string, status: VerificationStatus, notes?: string) => {
    setAllTeachers(prev =>
      prev.map(t => {
        if (t.id === teacherId) {
          return {
            ...t,
            verificationStatus: status,
            verificationNotes: notes || (status === 'verified' ? 'Degrees and identity verified by TutorConnect Admin.' : 'Qualifications could not be verified.')
          };
        }
        return t;
      })
    );
  };

  const toggleBlockUser = (userId: string) => {
    setAllUsers(prev =>
      prev.map(u => {
        if (u.id === userId && u.role !== 'admin') {
          const nextBlocked = !u.isBlocked;
          return { ...u, isBlocked: nextBlocked };
        }
        return u;
      })
    );

    setAllTeachers(prev =>
      prev.map(t => (t.userId === userId ? { ...t, isBlocked: !t.isBlocked } : t))
    );

    setAllStudents(prev =>
      prev.map(s => (s.userId === userId ? { ...s, isBlocked: !s.isBlocked } : s))
    );

    // If current user blocked themselves, log out
    if (currentUser?.id === userId) {
      setCurrentUser(prev => (prev ? { ...prev, isBlocked: !prev.isBlocked } : null));
    }
  };

  const updateTeacherProfile = (updatedData: Partial<TeacherProfile>) => {
    if (!currentTeacherProfile) return;
    setAllTeachers(prev =>
      prev.map(t => {
        if (t.id === currentTeacherProfile.id) {
          return { ...t, ...updatedData };
        }
        return t;
      })
    );
  };

  const updateStudentProfile = (updatedData: Partial<StudentProfile>) => {
    if (!currentStudentProfile) return;
    setAllStudents(prev =>
      prev.map(s => {
        if (s.id === currentStudentProfile.id) {
          return { ...s, ...updatedData };
        }
        return s;
      })
    );

    if (updatedData.avatarUrl) {
      setAllUsers(prev =>
        prev.map(u => (u.id === currentStudentProfile.userId ? { ...u, avatarUrl: updatedData.avatarUrl } : u))
      );
      if (currentUser?.id === currentStudentProfile.userId) {
        setCurrentUser(prev => (prev ? { ...prev, avatarUrl: updatedData.avatarUrl } : null));
      }
    }
  };

  const resetAllData = () => {
    localStorage.clear();
    setAllUsers(INITIAL_USERS);
    setAllTeachers(INITIAL_TEACHERS);
    setAllStudents(INITIAL_STUDENTS);
    setAllRequests(INITIAL_REQUESTS);
    setCurrentUser(INITIAL_USERS.find(u => u.id === 'user-stud-1') || null);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentTeacherProfile,
        currentStudentProfile,
        allUsers,
        allTeachers,
        allStudents,
        allRequests,
        login,
        register,
        logout,
        switchDemoUser,
        sendTuitionRequest,
        respondToTuitionRequest,
        verifyTeacher,
        toggleBlockUser,
        updateTeacherProfile,
        updateStudentProfile,
        resetAllData
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
