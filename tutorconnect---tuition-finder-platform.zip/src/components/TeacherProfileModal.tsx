import React from 'react';
import { TeacherProfile } from '../types';
import {
  X,
  ShieldCheck,
  Star,
  MapPin,
  Clock,
  GraduationCap,
  Briefcase,
  Wifi,
  Home,
  CheckCircle2,
  FileCheck2,
  Mail,
  Phone,
  Send
} from 'lucide-react';

interface TeacherProfileModalProps {
  teacher: TeacherProfile | null;
  onClose: () => void;
  onRequestTuition: (teacher: TeacherProfile) => void;
}

export const TeacherProfileModal: React.FC<TeacherProfileModalProps> = ({
  teacher,
  onClose,
  onRequestTuition
}) => {
  if (!teacher) return null;

  const isVerified = teacher.verificationStatus === 'verified';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header Cover Banner */}
        <div className="bg-gradient-to-r from-indigo-700 via-indigo-800 to-slate-900 p-6 sm:p-8 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
            <div className="relative">
              <img
                src={teacher.avatarUrl}
                alt={teacher.name}
                className="w-24 h-24 rounded-2xl object-cover ring-4 ring-white/20 shadow-lg"
              />
              {isVerified && (
                <span className="absolute -bottom-2 -right-2 bg-emerald-500 text-white p-1.5 rounded-full ring-2 ring-indigo-900 shadow-md">
                  <CheckCircle2 className="w-4 h-4" />
                </span>
              )}
            </div>

            <div className="text-center sm:text-left flex-1">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h2 className="text-2xl font-extrabold">{teacher.name}</h2>
                {isVerified ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-400/20 text-emerald-300 border border-emerald-400/30">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified Teacher
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                    Pending Verification
                  </span>
                )}
              </div>

              <p className="text-indigo-200 text-sm mt-1 flex items-center justify-center sm:justify-start gap-1.5">
                <GraduationCap className="w-4 h-4" />
                {teacher.qualification}
              </p>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 mt-3 text-xs text-indigo-100">
                <span className="flex items-center gap-1">
                  <Briefcase className="w-3.5 h-3.5 text-indigo-300" />
                  {teacher.experience} Years Teaching Experience
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-indigo-300" />
                  {teacher.location}
                </span>
                <span className="flex items-center gap-1 text-amber-300 font-semibold">
                  <Star className="w-3.5 h-3.5 fill-amber-300" />
                  {teacher.rating.toFixed(1)} ({teacher.reviewCount} reviews)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* Verification Badge Details */}
          {isVerified ? (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
              <FileCheck2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-emerald-900">Admin-Verified Credential</p>
                <p className="text-emerald-700 mt-0.5">
                  {teacher.verificationNotes || 'Academic degree certificates, identity, and teaching credentials have been verified by TutorConnect.'}
                </p>
                {teacher.degreesDocuments && (
                  <p className="text-emerald-800 font-medium mt-1">
                    Verified Document: <span className="font-mono bg-emerald-100 px-1.5 py-0.5 rounded">{teacher.degreesDocuments}</span>
                  </p>
                )}
              </div>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-start gap-3">
              <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-amber-900">Verification in Progress</p>
                <p className="text-amber-700 mt-0.5">
                  This tutor's credentials are currently being reviewed by our Admin compliance team.
                </p>
              </div>
            </div>
          )}

          {/* About Section */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">About the Teacher</h4>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed whitespace-pre-line">
              {teacher.about}
            </p>
          </div>

          {/* Subjects & Classes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Subjects Offered</h4>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {teacher.subjects.map((sub, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-md text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100"
                  >
                    {sub}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Target Classes / Grades</h4>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {teacher.classes.map((cls, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-md text-xs font-semibold bg-white text-slate-700 border border-slate-200 shadow-xs"
                  >
                    {cls}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Teaching Mode & Available Timings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Mode of Teaching</h4>
              <div className="mt-2 text-sm text-slate-700 font-medium">
                {teacher.teachingMode === 'online' && (
                  <span className="flex items-center gap-1.5 text-sky-700">
                    <Wifi className="w-4 h-4 text-sky-500" />
                    100% Online Classes (Google Meet / Zoom)
                  </span>
                )}
                {teacher.teachingMode === 'offline' && (
                  <span className="flex items-center gap-1.5 text-amber-700">
                    <Home className="w-4 h-4 text-amber-600" />
                    In-Person / Home Visits at Student's Place
                  </span>
                )}
                {teacher.teachingMode === 'both' && (
                  <span className="flex items-center gap-1.5 text-indigo-700">
                    <Wifi className="w-4 h-4 text-indigo-500" />
                    Online & Offline / Home Tuition Available
                  </span>
                )}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Available Timing Slots</h4>
              <ul className="mt-2 space-y-1 text-xs text-slate-700">
                {teacher.availableTimings.map((time, idx) => (
                  <li key={idx} className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-indigo-500" />
                    <span>{time}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Fees breakdown */}
          <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex items-center justify-between">
            <div>
              <span className="text-xs uppercase font-bold text-indigo-900 tracking-wider">Tuition Fees</span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-2xl font-black text-indigo-950">₹{teacher.hourlyFee}</span>
                <span className="text-xs font-semibold text-indigo-700">per hour</span>
                <span className="text-slate-400 mx-1">|</span>
                <span className="text-sm font-bold text-indigo-900">₹{teacher.monthlyFee}</span>
                <span className="text-xs text-indigo-700">monthly package</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-200 transition-colors"
          >
            Close
          </button>
          <button
            onClick={() => {
              onClose();
              onRequestTuition(teacher);
            }}
            className="px-5 py-2.5 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-200 flex items-center gap-2 transition-all"
          >
            <Send className="w-4 h-4" />
            <span>Send Tuition Request</span>
          </button>
        </div>
      </div>
    </div>
  );
};
