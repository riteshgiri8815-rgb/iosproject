import React, { useState } from 'react';
import { PHP_PROJECT_FILES, XAMPP_INSTRUCTIONS } from '../data/phpCodeExport';
import {
  X,
  Copy,
  Check,
  Download,
  FolderTree,
  FileCode,
  Database,
  Terminal,
  Server,
  BookOpen
} from 'lucide-react';

interface XamppExportModalProps {
  onClose: () => void;
}

export const XamppExportModal: React.FC<XamppExportModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'code' | 'sql' | 'guide' | 'structure'>('sql');
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);

  const selectedFile = PHP_PROJECT_FILES[selectedFileIndex] || PHP_PROJECT_FILES[0];

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = (fileName: string, content: string) => {
    const element = document.createElement('a');
    const file = new Blob([content], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = fileName.split('/').pop() || 'tutorconnect-file.txt';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-slate-900 text-slate-100 rounded-3xl max-w-5xl w-full shadow-2xl border border-slate-800 overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white">
                  TutorConnect <span className="text-sky-400">PHP + MySQL (XAMPP)</span> Package
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-950 text-sky-300 border border-sky-800">
                  Ready to run
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Complete database SQL, production PHP backend scripts, and full deployment guide for localhost XAMPP.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 gap-2 text-sm font-semibold overflow-x-auto">
          <button
            onClick={() => {
              setActiveTab('sql');
              setSelectedFileIndex(0);
            }}
            className={`py-3.5 px-4 flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'sql'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-4 h-4 text-emerald-400" />
            <span>1. MySQL Database (.sql)</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`py-3.5 px-4 flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'code'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-4 h-4 text-indigo-400" />
            <span>2. PHP Backend Code Files</span>
          </button>

          <button
            onClick={() => setActiveTab('structure')}
            className={`py-3.5 px-4 flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'structure'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderTree className="w-4 h-4 text-amber-400" />
            <span>3. Folder Structure</span>
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`py-3.5 px-4 flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'guide'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4 text-sky-400" />
            <span>4. Step-by-Step XAMPP Setup</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          {/* If viewing PHP code, show file selector list on left */}
          {activeTab === 'code' && (
            <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-800 bg-slate-950/40 p-4 overflow-y-auto space-y-1">
              <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">
                Project Files ({PHP_PROJECT_FILES.length})
              </p>
              {PHP_PROJECT_FILES.map((file, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono transition-colors flex items-center justify-between ${
                    selectedFileIndex === idx
                      ? 'bg-sky-600/20 text-sky-300 border border-sky-500/40 font-bold'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <span className="truncate">{file.path}</span>
                  <span className="text-[10px] uppercase font-bold text-slate-500">
                    {file.language}
                  </span>
                </button>
              ))}
            </div>
          )}

          {/* Code Viewer Panel */}
          {(activeTab === 'code' || activeTab === 'sql') && (
            <div className="flex-1 flex flex-col overflow-hidden bg-slate-950">
              <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-sky-300">
                    {activeTab === 'sql' ? 'database/tutorconnect.sql' : selectedFile.path}
                  </span>
                  <span className="text-xs text-slate-400 hidden sm:inline">
                    — {activeTab === 'sql' ? 'Ready to import into phpMyAdmin' : selectedFile.description}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      handleCopy(
                        activeTab === 'sql' ? PHP_PROJECT_FILES[0].content : selectedFile.content
                      )
                    }
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 transition-colors border border-slate-700"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy File</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() =>
                      handleDownloadFile(
                        activeTab === 'sql' ? 'tutorconnect.sql' : selectedFile.path,
                        activeTab === 'sql' ? PHP_PROJECT_FILES[0].content : selectedFile.content
                      )
                    }
                    className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>

              <div className="flex-1 p-4 overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed select-text bg-slate-950">
                <pre className="whitespace-pre">
                  {activeTab === 'sql' ? PHP_PROJECT_FILES[0].content : selectedFile.content}
                </pre>
              </div>
            </div>
          )}

          {/* Folder Structure Tab */}
          {activeTab === 'structure' && (
            <div className="flex-1 p-6 overflow-y-auto bg-slate-950">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
                <FolderTree className="w-4 h-4 text-amber-400" />
                Recommended XAMPP Folder Structure
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Place this entire directory inside <code className="bg-slate-800 px-1.5 py-0.5 rounded text-sky-300">C:\xampp\htdocs\tutorconnect</code> on Windows (or <code className="bg-slate-800 px-1.5 py-0.5 rounded text-sky-300">/Applications/XAMPP/xamppfiles/htdocs/tutorconnect</code> on macOS).
              </p>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 font-mono text-xs text-slate-300 leading-loose">
                <div>📁 tutorconnect/</div>
                <div className="pl-4">├── 📁 config/</div>
                <div className="pl-8">└── 📄 db.php <span className="text-slate-500">(PDO MySQL database connection)</span></div>
                <div className="pl-4">├── 📁 database/</div>
                <div className="pl-8">└── 📄 tutorconnect.sql <span className="text-slate-500">(Database schema & admin seeds)</span></div>
                <div className="pl-4">├── 📁 auth/</div>
                <div className="pl-8">├── 📄 login.php <span className="text-slate-500">(Multi-role login: student, teacher, admin)</span></div>
                <div className="pl-8">├── 📄 register.php <span className="text-slate-500">(Registration with profile details)</span></div>
                <div className="pl-8">└── 📄 logout.php</div>
                <div className="pl-4">├── 📁 student/</div>
                <div className="pl-8">├── 📄 dashboard.php <span className="text-slate-500">(My requests & profile management)</span></div>
                <div className="pl-8">├── 📄 search.php <span className="text-slate-500">(Tutor search with SQL filters)</span></div>
                <div className="pl-8">└── 📄 send_request.php</div>
                <div className="pl-4">├── 📁 teacher/</div>
                <div className="pl-8">├── 📄 dashboard.php <span className="text-slate-500">(Incoming requests, verification status)</span></div>
                <div className="pl-8">├── 📄 update_profile.php</div>
                <div className="pl-8">└── 📄 respond_request.php <span className="text-slate-500">(Accept/reject tuition requests)</span></div>
                <div className="pl-4">├── 📁 admin/</div>
                <div className="pl-8">├── 📄 dashboard.php <span className="text-slate-500">(Metrics, verification & user management)</span></div>
                <div className="pl-8">├── 📄 verify_teacher.php <span className="text-slate-500">(Approve/reject teacher badges)</span></div>
                <div className="pl-8">└── 📄 block_user.php <span className="text-slate-500">(Suspend/unsuspend student/teacher)</span></div>
                <div className="pl-4">├── 📁 assets/ <span className="text-slate-500">(css, js, images, uploads)</span></div>
                <div className="pl-4">└── 📄 index.php <span className="text-slate-500">(Homepage with search bar)</span></div>
              </div>
            </div>
          )}

          {/* Step-by-Step Guide Tab */}
          {activeTab === 'guide' && (
            <div className="flex-1 p-6 overflow-y-auto bg-slate-950 space-y-6">
              <div className="p-4 rounded-2xl bg-indigo-950/60 border border-indigo-800 text-xs">
                <h4 className="text-sm font-bold text-indigo-200">Default Administrator Credentials:</h4>
                <p className="mt-1 text-slate-300">
                  Email: <span className="font-mono bg-slate-900 px-2 py-0.5 rounded text-sky-300">admin@tutorconnect.com</span> | Password: <span className="font-mono bg-slate-900 px-2 py-0.5 rounded text-sky-300">admin123</span>
                </p>
              </div>

              <div className="prose prose-invert max-w-none text-xs leading-relaxed text-slate-300 space-y-4">
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center font-bold text-xs">1</span>
                    Install and Start XAMPP
                  </h4>
                  <p className="text-slate-400">
                    Download XAMPP from apachefriends.org. Open the XAMPP Control Panel and start both <strong>Apache</strong> and <strong>MySQL</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center font-bold text-xs">2</span>
                    Create Database in phpMyAdmin
                  </h4>
                  <p className="text-slate-400">
                    Visit <code className="bg-slate-800 text-sky-300 px-1 py-0.5 rounded">http://localhost/phpmyadmin</code> in your browser. Click <strong>Databases</strong>, name it <code className="bg-slate-800 text-sky-300 px-1 py-0.5 rounded">tutorconnect</code>, and click <strong>Create</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center font-bold text-xs">3</span>
                    Import the SQL File
                  </h4>
                  <p className="text-slate-400">
                    Under the <code className="bg-slate-800 text-sky-300 px-1 py-0.5 rounded">tutorconnect</code> database, click the <strong>Import</strong> tab, select <code className="bg-slate-800 text-sky-300 px-1 py-0.5 rounded">tutorconnect.sql</code> from tab 1, and click <strong>Go</strong>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center font-bold text-xs">4</span>
                    Copy Code to htdocs
                  </h4>
                  <p className="text-slate-400">
                    Extract all project files into <code className="bg-slate-800 text-sky-300 px-1 py-0.5 rounded">htdocs/tutorconnect/</code>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-bold text-xs">5</span>
                    Open and Test
                  </h4>
                  <p className="text-slate-400">
                    Visit <code className="bg-slate-800 text-emerald-400 px-1 py-0.5 rounded font-bold">http://localhost/tutorconnect/</code> to test registration, search filters, sending tuition requests, teacher approval badges, and admin management!
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Bar */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>All SQL statements use prepared PDO statements for SQL injection prevention.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors"
          >
            Close Viewer
          </button>
        </div>
      </div>
    </div>
  );
};
