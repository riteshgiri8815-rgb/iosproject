import React, { useState } from 'react';
import {
  Phone,
  PhoneCall,
  X,
  MessageSquare,
  Clock,
  CheckCircle2,
  Headphones,
  ShieldCheck,
  GraduationCap,
  Briefcase,
  Copy,
  Check,
  Send,
  Sparkles,
  HelpCircle,
  FileCheck2,
  Calendar
} from 'lucide-react';

interface HelplineModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CallbackRequest {
  id: string;
  name: string;
  phone: string;
  role: 'student' | 'teacher';
  queryType: string;
  timestamp: string;
  status: 'scheduled' | 'connecting';
}

export const HelplineModal: React.FC<HelplineModalProps> = ({ isOpen, onClose }) => {
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  // Callback form state
  const [callerName, setCallerName] = useState('');
  const [callerPhone, setCallerPhone] = useState('');
  const [callerRole, setCallerRole] = useState<'student' | 'teacher'>('student');
  const [queryType, setQueryType] = useState('Finding the Right Tutor');
  const [preferredTime, setPreferredTime] = useState('Within 15 minutes');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [callbackSuccess, setCallbackSuccess] = useState(false);

  // Stored callbacks
  const [callbackHistory, setCallbackHistory] = useState<CallbackRequest[]>(() => {
    try {
      const saved = localStorage.getItem('tutorconnect_callbacks');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  if (!isOpen) return null;

  const tollFreeNumber = '1800-889-2026';
  const whatsappNumber = '+91 98765 43210';
  const directCounselorPhone = '+91 80 4567 8900';

  const handleCopy = (num: string, label: string) => {
    navigator.clipboard.writeText(num.replace(/\s+/g, ''));
    setCopiedNumber(label);
    setTimeout(() => setCopiedNumber(null), 2500);
  };

  const handleCallbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!callerName.trim() || !callerPhone.trim()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const newRequest: CallbackRequest = {
        id: 'CB-' + Math.floor(100000 + Math.random() * 900000),
        name: callerName,
        phone: callerPhone,
        role: callerRole,
        queryType,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'scheduled'
      };

      const updated = [newRequest, ...callbackHistory.slice(0, 4)];
      setCallbackHistory(updated);
      try {
        localStorage.setItem('tutorconnect_callbacks', JSON.stringify(updated));
      } catch (err) {
        console.error(err);
      }

      setIsSubmitting(false);
      setCallbackSuccess(true);
      setCallerName('');
      setCallerPhone('');
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-900 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-lg shadow-rose-500/20">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black">TutorConnect Academic Helpline</h2>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/20 border border-emerald-400/40 text-emerald-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  Lines Active
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Dedicated student, parent, and educator phone support across India
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {/* Primary Toll-Free Call Box */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-500/10 via-rose-500/5 to-indigo-500/10 border-2 border-amber-300/60 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-center sm:text-left">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center shadow-md shadow-amber-500/30 shrink-0">
                <PhoneCall className="w-7 h-7 animate-bounce-subtle" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                  All-India Toll-Free Helpline
                </span>
                <p className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-1 font-mono">
                  {tollFreeNumber}
                </p>
                <p className="text-xs text-slate-500 flex items-center justify-center sm:justify-start gap-1.5 mt-0.5">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Mon – Sun: 8:00 AM – 10:00 PM IST (Zero Calling Charges)</span>
                </p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <a
                href={`tel:${tollFreeNumber.replace(/-/g, '')}`}
                className="px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 transition-all hover:scale-102"
              >
                <Phone className="w-4 h-4 fill-slate-950" />
                <span>Call Now (Free)</span>
              </a>
              <button
                type="button"
                onClick={() => handleCopy(tollFreeNumber, 'tollfree')}
                className="px-3.5 py-3 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                title="Copy Toll-Free Number"
              >
                {copiedNumber === 'tollfree' ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600 stroke-[3]" />
                    <span className="text-emerald-700">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-500" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Direct Desk Grid */}
          <div>
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
              Direct Support Desks & WhatsApp Assistance
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* WhatsApp Academic Desk */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-emerald-950">WhatsApp Academic Desk</h4>
                    <p className="text-[11px] text-emerald-700 font-mono mt-0.5">{whatsappNumber}</p>
                    <p className="text-[10px] text-emerald-600">Quick tuition matches & inquiries</p>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(whatsappNumber, 'whatsapp')}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shrink-0"
                >
                  {copiedNumber === 'whatsapp' ? (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  ) : (
                    <span>Chat / Copy</span>
                  )}
                </button>
              </div>

              {/* Teacher Verification Desk */}
              <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200/80 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs text-indigo-950">Teacher Verification Desk</h4>
                    <p className="text-[11px] text-indigo-700 font-mono mt-0.5">{directCounselorPhone}</p>
                    <p className="text-[10px] text-indigo-600">Extn #2 for document approvals</p>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(directCounselorPhone, 'verification')}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1 shrink-0"
                >
                  {copiedNumber === 'verification' ? (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  ) : (
                    <span>Copy</span>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Interactive IVR Extension Reference */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
            <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-1.5">
              <Headphones className="w-4 h-4 text-indigo-600" />
              <span>When Calling 1800-889-2026, Press:</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 text-center">
                <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[11px] font-bold inline-flex items-center justify-center mb-1">
                  1
                </span>
                <p className="font-bold text-[11px] text-slate-800">Student & Parents</p>
                <p className="text-[10px] text-slate-500">Tutor Match</p>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 text-center">
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[11px] font-bold inline-flex items-center justify-center mb-1">
                  2
                </span>
                <p className="font-bold text-[11px] text-slate-800">Educators</p>
                <p className="text-[10px] text-slate-500">Verification Help</p>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 text-center">
                <span className="w-5 h-5 rounded-full bg-amber-600 text-white text-[11px] font-bold inline-flex items-center justify-center mb-1">
                  3
                </span>
                <p className="font-bold text-[11px] text-slate-800">Entrance Exams</p>
                <p className="text-[10px] text-slate-500">IIT-JEE & NEET</p>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200 text-center">
                <span className="w-5 h-5 rounded-full bg-purple-600 text-white text-[11px] font-bold inline-flex items-center justify-center mb-1">
                  4
                </span>
                <p className="font-bold text-[11px] text-slate-800">Technical Help</p>
                <p className="text-[10px] text-slate-500">App & Account</p>
              </div>
            </div>
          </div>

          {/* Request an Immediate Callback Section */}
          <div className="pt-2 border-t border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-1.5">
                  <PhoneCall className="w-4 h-4 text-emerald-600" />
                  <span>Prefer Us to Call You Back?</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Leave your number. Our counselor will connect with you within 15 minutes.
                </p>
              </div>
            </div>

            {callbackSuccess ? (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-2 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <p className="font-bold text-sm">Callback Scheduled Successfully!</p>
                </div>
                <p className="text-xs text-emerald-800 leading-relaxed">
                  Our academic counselor has received your request. We will ring your phone shortly with tailored guidance for your academic query.
                </p>
                <button
                  type="button"
                  onClick={() => setCallbackSuccess(false)}
                  className="mt-1 text-xs font-bold text-emerald-700 underline"
                >
                  Request another callback
                </button>
              </div>
            ) : (
              <form onSubmit={handleCallbackSubmit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ramesh Verma"
                      value={callerName}
                      onChange={e => setCallerName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Phone Number (10 digits) *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 98765 43210"
                      value={callerPhone}
                      onChange={e => setCallerPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">I am a *</label>
                    <select
                      value={callerRole}
                      onChange={e => setCallerRole(e.target.value as 'student' | 'teacher')}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden bg-white"
                    >
                      <option value="student">Student / Parent</option>
                      <option value="teacher">Teacher / Educator</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Reason for Call</label>
                    <select
                      value={queryType}
                      onChange={e => setQueryType(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden bg-white"
                    >
                      <option value="Finding the Right Tutor">Finding the Right Tutor</option>
                      <option value="IIT-JEE / NEET Counseling">IIT-JEE / NEET Counseling</option>
                      <option value="Teacher Verification Help">Teacher Verification Help</option>
                      <option value="Fee & Batch Discussion">Fee & Batch Discussion</option>
                      <option value="Other Assistance">Other Assistance</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">Preferred Time</label>
                    <select
                      value={preferredTime}
                      onChange={e => setPreferredTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-amber-500 focus:outline-hidden bg-white"
                    >
                      <option value="Within 15 minutes">Within 15 minutes</option>
                      <option value="Today Evening (5 PM - 8 PM)">Today Evening (5-8 PM)</option>
                      <option value="Tomorrow Morning">Tomorrow Morning</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Scheduling Callback...' : 'Request Instant Callback'}</span>
                </button>
              </form>
            )}
          </div>

          {/* Callback Log if user submitted any */}
          {callbackHistory.length > 0 && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
              <span className="font-bold text-slate-700 block mb-1">Recent Callback Requests:</span>
              <div className="space-y-1">
                {callbackHistory.map(cb => (
                  <div key={cb.id} className="flex items-center justify-between text-[11px] text-slate-600 py-1 border-b border-slate-100 last:border-0">
                    <span className="font-semibold text-slate-800">{cb.name} ({cb.phone})</span>
                    <span className="text-slate-500">{cb.queryType} • {cb.timestamp}</span>
                    <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                      Pending Call
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>TutorConnect Official Helpline Support Service</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
