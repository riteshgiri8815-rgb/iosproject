import React from 'react';

export interface AnimatedAvatarOption {
  id: string;
  name: string;
  url: string;
  category: string;
  badge: string;
}

export const ANIMATED_STUDENT_AVATARS: AnimatedAvatarOption[] = [
  {
    id: 'student-aarav-animated',
    name: 'Aarav (Animated Scholar)',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Aarav&backgroundColor=b6e3f4&hair=short01,short02&accessories=glasses&clothing=hoodie',
    category: 'Scholar',
    badge: '🎓 Math & Science'
  },
  {
    id: 'student-sneha-animated',
    name: 'Sneha (Animated Achiever)',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Sneha&backgroundColor=ffd5dc&hair=long01,long02&accessories=glasses',
    category: 'STEM',
    badge: '🔬 Science & Coding'
  },
  {
    id: 'student-kabir-animated',
    name: 'Kabir (Animated Tech Student)',
    url: 'https://api.dicebear.com/7.x/bottts/svg?seed=Kabir&backgroundColor=c0aede',
    category: 'Tech',
    badge: '💻 Computer Science'
  },
  {
    id: 'student-ananya-animated',
    name: 'Diya (Animated Explorer)',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Diya&backgroundColor=ffdfbf&hair=long05',
    category: 'Humanities',
    badge: '📚 English Literature'
  },
  {
    id: 'student-rohan-animated',
    name: 'Rohan (Animated Aspirant)',
    url: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Rohan&backgroundColor=d1d4f9&accessories=sunglasses',
    category: 'JEE Prep',
    badge: '⚡ IIT-JEE Aspirant'
  },
  {
    id: 'student-gif-3d',
    name: 'Alex (Animated 3D GIF)',
    url: 'https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif',
    category: '3D Cartoon',
    badge: '✨ Animated Motion'
  }
];

export const DEFAULT_ANIMATED_STUDENT_AVATAR = ANIMATED_STUDENT_AVATARS[0].url;
export const DEFAULT_ANIMATED_STUDENT_SNEHA = ANIMATED_STUDENT_AVATARS[1].url;

interface AnimatedStudentAvatarProps {
  src?: string;
  name?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showAnimationRings?: boolean;
  showFloatingIcons?: boolean;
  className?: string;
}

export const AnimatedStudentAvatar: React.FC<AnimatedStudentAvatarProps> = ({
  src = DEFAULT_ANIMATED_STUDENT_AVATAR,
  name = 'Student',
  size = 'md',
  showAnimationRings = true,
  showFloatingIcons = false,
  className = ''
}) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24'
  };

  const isGif = src.includes('.gif') || src.includes('giphy');

  return (
    <div className={`relative inline-flex items-center justify-center shrink-0 ${className}`}>
      {/* Animated Glowing Ring Effect */}
      {showAnimationRings && (
        <span className="absolute -inset-1 rounded-2xl bg-gradient-to-tr from-indigo-500 via-sky-400 to-emerald-400 opacity-75 blur-xs animate-pulse"></span>
      )}

      {/* Main Avatar Container */}
      <div
        className={`relative ${sizeClasses[size]} rounded-2xl overflow-hidden bg-gradient-to-tr from-sky-100 to-indigo-100 border-2 border-white shadow-md flex items-center justify-center`}
      >
        <img
          src={src || DEFAULT_ANIMATED_STUDENT_AVATAR}
          alt={name}
          className={`w-full h-full object-cover transition-transform duration-300 hover:scale-110 ${
            !isGif ? 'animate-bounce-subtle' : ''
          }`}
          loading="lazy"
        />

        {/* Live Active Glow Dot */}
        <span className="absolute bottom-1 right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white shadow-xs"></span>
      </div>

      {/* Floating Animated Study Icons (Optional for Dashboard & Profile headers) */}
      {showFloatingIcons && (
        <>
          <span
            className="absolute -top-2 -right-2 bg-white rounded-full p-1 shadow-md text-xs border border-indigo-100 animate-float-slow"
            title="Active Student"
          >
            🎓
          </span>
          <span
            className="absolute -bottom-1 -left-2 bg-white rounded-full p-1 shadow-md text-[10px] border border-sky-100 animate-float-reverse"
            title="Study Goal Active"
          >
            📚
          </span>
        </>
      )}
    </div>
  );
};
