import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  GraduationCap,
  Briefcase,
  Search,
  UserCheck,
  Shield,
  LogOut,
  Menu,
  X,
  FileCode2,
  ChevronDown,
  Layers,
  Sparkles,
  LogIn,
  PhoneCall
} from 'lucide-react';

interface NavbarProps {
  currentTab: 'home' | 'search' | 'dashboard' | 'admin';
  onSelectTab: (tab: 'home' | 'search' | 'dashboard' | 'admin') => void;
  onOpenAuth: (mode: 'login' | 'register', role?: 'student' | 'teacher' | 'admin') => void;
  onOpenXamppModal: () => void;
  onOpenHelpline: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  onOpenAuth,
  onOpenXamppModal,
  onOpenHelpline
}) => {
  const { currentUser, logout, allRequests, allTeachers } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  // Calculate unread/pending badges
  const pendingRequestsCount = React.useMemo(() => {
    if (!currentUser) return 0;
    if (currentUser.role === 'teacher') {
      const teacherProfile = allTeachers.find(t => t.userId === currentUser.id || t.email === currentUser.email);
      if (!teacherProfile) return 0;
      return allRequests.filter(r => r.teacherId === teacherProfile.id && r.status === 'pending').length;
    }
    if (currentUser.role === 'student') {
      return allRequests.filter(r => (r.studentEmail === currentUser.email || r.studentId === currentUser.id) && r.status === 'accepted').length;
    }
    return 0;
  }, [currentUser, allTeachers, allRequests]);

  const pendingVerificationsCount = React.useMemo(() => {
    return allTeachers.filter(t => t.verificationStatus === 'pending').length;
  }, [allTeachers]);

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-[33px] z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-8">
            <button
              onClick={() => onSelectTab('home')}
              className="flex items-center gap-2.5 text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-indigo-100 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 bg-clip-text text-transparent">
                  Tutor<span className="text-indigo-600">Connect</span>
                </span>
                <span className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 -mt-1">
                  Tuition Finder
                </span>
              </div>
            </button>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-center gap-1">
              <button
                onClick={() => onSelectTab('home')}
                className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors ${
                  currentTab === 'home'
                    ? 'text-indigo-600 bg-indigo-50/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                Home
              </button>

              <button
                onClick={() => onSelectTab('search')}
                className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                  currentTab === 'search'
                    ? 'text-indigo-600 bg-indigo-50/80'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Search className="w-4 h-4" />
                Find Tutors
              </button>

              {/* Conditional Dashboard Link */}
              {currentUser && (
                <button
                  onClick={() => onSelectTab(currentUser.role === 'admin' ? 'admin' : 'dashboard')}
                  className={`px-3.5 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                    currentTab === 'dashboard' || currentTab === 'admin'
                      ? 'text-indigo-600 bg-indigo-50/80'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  {currentUser.role === 'admin' ? (
                    <>
                      <Shield className="w-4 h-4 text-purple-600" />
                      <span>Admin Panel</span>
                      {pendingVerificationsCount > 0 && (
                        <span className="ml-1 px-1.5 py-0.5 text-xs font-bold bg-amber-500 text-white rounded-full">
                          {pendingVerificationsCount}
                        </span>
                      )}
                    </>
                  ) : currentUser.role === 'teacher' ? (
                    <>
                      <UserCheck className="w-4 h-4 text-emerald-600" />
                      <span>Teacher Dashboard</span>
                      {pendingRequestsCount > 0 && (
                        <span className="ml-1 px-1.5 py-0.5 text-xs font-bold bg-rose-500 text-white rounded-full">
                          {pendingRequestsCount}
                        </span>
                      )}
                    </>
                  ) : (
                    <>
                      <GraduationCap className="w-4 h-4 text-indigo-600" />
                      <span>Student Dashboard</span>
                      {pendingRequestsCount > 0 && (
                        <span className="ml-1 px-1.5 py-0.5 text-xs font-bold bg-emerald-500 text-white rounded-full" title="Accepted requests">
                          {pendingRequestsCount}
                        </span>
                      )}
                    </>
                  )}
                </button>
              )}

              {/* XAMPP & PHP Source Code Button */}
              <button
                onClick={onOpenXamppModal}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:text-indigo-700 hover:bg-indigo-50/50 border border-slate-200 flex items-center gap-1.5 transition-all"
                title="View full PHP code and XAMPP MySQL database instructions"
              >
                <FileCode2 className="w-3.5 h-3.5 text-indigo-600" />
                <span>PHP + MySQL Files</span>
              </button>
            </div>
          </div>

          {/* Right Action Buttons */}
          <div className="hidden md:flex items-center gap-2.5">
            {/* Desktop Helpline Button */}
            <button
              onClick={onOpenHelpline}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-900 border border-amber-300 text-xs font-bold transition-all shadow-xs shrink-0"
              title="Click to open TutorConnect Academic Helpline Center"
            >
              <PhoneCall className="w-3.5 h-3.5 text-amber-600 animate-bounce-subtle" />
              <span className="hidden lg:inline">Helpline:</span>
              <span className="font-mono text-amber-800">1800-889-2026</span>
            </button>
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2.5 p-1.5 pr-3 rounded-full hover:bg-slate-100 transition-colors border border-slate-200"
                >
                  <img
                    src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'}
                    alt={currentUser.name}
                    className="w-8 h-8 rounded-full object-cover border border-slate-200 shadow-xs"
                  />
                  <div className="text-left text-xs">
                    <p className="font-semibold text-slate-800 line-clamp-1">{currentUser.name}</p>
                    <p className="text-slate-500 text-[11px] capitalize">{currentUser.role}</p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-slate-200 shadow-xl py-2 z-50">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs text-slate-500">Signed in as</p>
                      <p className="text-sm font-bold text-slate-800 truncate">{currentUser.email}</p>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                        {currentUser.role}
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        onSelectTab(currentUser.role === 'admin' ? 'admin' : 'dashboard');
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Layers className="w-4 h-4 text-indigo-500" />
                      <span>My Dashboard</span>
                    </button>

                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        onOpenXamppModal();
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <FileCode2 className="w-4 h-4 text-sky-500" />
                      <span>XAMPP Code Export</span>
                    </button>

                    <div className="border-t border-slate-100 my-1"></div>

                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        logout();
                      }}
                      className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Log Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenAuth('login', 'student')}
                  className="px-3 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50/90 hover:bg-indigo-100 rounded-xl transition-colors flex items-center gap-1.5 border border-indigo-200"
                >
                  <GraduationCap className="w-4 h-4 text-indigo-600" />
                  <span>Student Login</span>
                </button>

                <button
                  onClick={() => onOpenAuth('login', 'teacher')}
                  className="px-3 py-1.5 text-xs font-bold text-emerald-700 bg-emerald-50/90 hover:bg-emerald-100 rounded-xl transition-colors flex items-center gap-1.5 border border-emerald-200"
                >
                  <Briefcase className="w-4 h-4 text-emerald-600" />
                  <span>Teacher Login</span>
                </button>

                <button
                  onClick={() => onOpenAuth('register', 'student')}
                  className="px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm shadow-indigo-200 transition-all hover:shadow-md"
                >
                  Sign Up
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                onSelectTab('home');
                setMobileMenuOpen(false);
              }}
              className="px-3 py-2 text-center rounded-lg text-sm font-medium bg-slate-50 text-slate-800"
            >
              Home
            </button>
            <button
              onClick={() => {
                onSelectTab('search');
                setMobileMenuOpen(false);
              }}
              className="px-3 py-2 text-center rounded-lg text-sm font-medium bg-indigo-50 text-indigo-700"
            >
              Find Tutors
            </button>
          </div>

          {currentUser && (
            <button
              onClick={() => {
                onSelectTab(currentUser.role === 'admin' ? 'admin' : 'dashboard');
                setMobileMenuOpen(false);
              }}
              className="w-full px-4 py-2.5 rounded-lg text-sm font-semibold bg-indigo-600 text-white flex items-center justify-between"
            >
              <span>{currentUser.role === 'admin' ? 'Admin Panel' : 'My Dashboard'}</span>
              <span className="text-xs bg-indigo-700 px-2 py-0.5 rounded capitalize">{currentUser.role}</span>
            </button>
          )}

          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenHelpline();
            }}
            className="w-full px-3 py-2.5 rounded-xl text-xs font-bold text-amber-900 bg-amber-50 border border-amber-300 flex items-center justify-center gap-2 shadow-xs"
          >
            <PhoneCall className="w-4 h-4 text-amber-600 animate-bounce-subtle" />
            <span>Academic Helpline: 1800-889-2026 (Toll-Free)</span>
          </button>

          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenXamppModal();
            }}
            className="w-full px-3 py-2 rounded-lg text-xs font-semibold text-sky-800 bg-sky-50 border border-sky-200 flex items-center justify-center gap-1.5"
          >
            <FileCode2 className="w-4 h-4 text-sky-600" />
            <span>View PHP / MySQL Source Code & XAMPP Setup</span>
          </button>

          <div className="border-t border-slate-100 pt-3">
            {currentUser ? (
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-slate-800">{currentUser.name}</p>
                  <p className="text-xs text-slate-500">{currentUser.email}</p>
                </div>
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-rose-600 bg-rose-50 rounded-lg"
                >
                  Log Out
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      onOpenAuth('login', 'student');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 px-3 text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center justify-center gap-1.5"
                  >
                    <GraduationCap className="w-4 h-4 text-indigo-600" />
                    <span>Student Login</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenAuth('login', 'teacher');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full py-2.5 px-3 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-center gap-1.5"
                  >
                    <Briefcase className="w-4 h-4 text-emerald-600" />
                    <span>Teacher Login</span>
                  </button>
                </div>

                <button
                  onClick={() => {
                    onOpenAuth('register', 'student');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs"
                >
                  Create New Account
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
