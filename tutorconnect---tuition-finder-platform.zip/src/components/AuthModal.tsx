import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole, TeachingMode } from '../types';
import { DEFAULT_ANIMATED_STUDENT_AVATAR } from './AnimatedStudentAvatar';
import { INDIAN_TEACHER_PHOTOS } from '../data/mockData';
import {
  X,
  GraduationCap,
  Briefcase,
  Shield,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles,
  ArrowRight,
  KeyRound,
  Check,
  HelpCircle,
  LogIn,
  UserPlus
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'login' | 'register';
  initialRole?: UserRole;
  onClose: () => void;
  onSuccess: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'login',
  initialRole = 'student',
  onClose,
  onSuccess
}) => {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [role, setRole] = useState<UserRole>(initialRole);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showForgotHelper, setShowForgotHelper] = useState(false);

  // Common fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');

  // Teacher specific fields
  const [qualification, setQualification] = useState('');
  const [experience, setExperience] = useState('5');
  const [subjects, setSubjects] = useState('');
  const [classes, setClasses] = useState('');
  const [location, setLocation] = useState('');
  const [city, setCity] = useState('');
  const [hourlyFee, setHourlyFee] = useState('600');
  const [teachingMode, setTeachingMode] = useState<TeachingMode>('both');
  const [about, setAbout] = useState('');

  // Student specific fields
  const [gradeClass, setGradeClass] = useState('Class 10 CBSE');
  const [targetSubjects, setTargetSubjects] = useState('Mathematics, Science');

  // Synchronize when opened with different props
  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setRole(initialRole);
      setError('');
      setShowForgotHelper(false);

      // Preload role defaults if fields empty
      if (initialRole === 'student') {
        setEmail('aarav.patel@student.com');
        setPassword('student123');
      } else if (initialRole === 'teacher') {
        setEmail('sunita.kulkarni@example.com');
        setPassword('teacher123');
      } else if (initialRole === 'admin') {
        setEmail('admin@tutorconnect.com');
        setPassword('admin123');
      }
    }
  }, [isOpen, initialMode, initialRole]);

  if (!isOpen) return null;

  // Fill quick demo credentials
  const fillDemoCredentials = (targetRole: UserRole) => {
    setError('');
    setRole(targetRole);
    if (targetRole === 'admin') {
      setEmail('admin@tutorconnect.com');
      setPassword('admin123');
    } else if (targetRole === 'teacher') {
      setEmail('sunita.kulkarni@example.com');
      setPassword('teacher123');
    } else {
      setEmail('aarav.patel@student.com');
      setPassword('student123');
    }
  };

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
    setError('');
    if (mode === 'login') {
      fillDemoCredentials(newRole);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'login') {
      if (!email.trim()) {
        setError('Please enter your email address.');
        return;
      }
      const res = login(email, password, role);
      if (res.success) {
        onSuccess();
        onClose();
      } else {
        setError(res.error || 'Login failed. Please check your credentials.');
      }
    } else {
      // Register
      if (!name.trim() || !email.trim() || !password.trim() || !phone.trim()) {
        setError('Please complete all required fields.');
        return;
      }

      let profileDetails: any = {};
      if (role === 'teacher') {
        if (!qualification.trim() || !subjects.trim() || !location.trim()) {
          setError('Please provide your educational qualification, subjects, and teaching location.');
          return;
        }
        profileDetails = {
          qualification,
          experience: Number(experience) || 1,
          subjects: subjects.split(',').map(s => s.trim()).filter(Boolean),
          classes: (classes || 'Class 9-10').split(',').map(c => c.trim()).filter(Boolean),
          location,
          city: city || location.split(',').pop()?.trim() || 'Delhi',
          hourlyFee: Number(hourlyFee) || 500,
          monthlyFee: (Number(hourlyFee) || 500) * 8,
          teachingMode,
          about: about || `Qualified teacher with ${experience} years experience in ${subjects}.`,
          availableTimings: ['Weekday Evenings (5:00 PM - 8:00 PM)', 'Weekend Batches'],
          degreesDocuments: 'Degree_Certificate_Uploaded.pdf'
        };
      } else if (role === 'student') {
        profileDetails = {
          gradeClass,
          targetSubjects: targetSubjects.split(',').map(s => s.trim()).filter(Boolean),
          location: location || 'Central Area',
          city: city || 'Delhi'
        };
      }

      const res = register(
        {
          name,
          email,
          phone,
          role,
          avatarUrl:
            role === 'teacher'
              ? INDIAN_TEACHER_PHOTOS[0].url
              : DEFAULT_ANIMATED_STUDENT_AVATAR
        },
        profileDetails
      );

      if (res.success) {
        onSuccess();
        onClose();
      } else {
        setError(res.error || 'Registration failed.');
      }
    }
  };

  const isStudent = role === 'student';
  const isTeacher = role === 'teacher';
  const isAdmin = role === 'admin';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Portal-Themed Header */}
        <div
          className={`p-6 text-white relative transition-colors duration-300 ${
            isStudent
              ? 'bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900'
              : isTeacher
              ? 'bg-gradient-to-r from-emerald-900 via-teal-950 to-slate-900'
              : 'bg-gradient-to-r from-purple-900 via-slate-900 to-slate-950'
          }`}
        >
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-1.5">
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                isStudent
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                  : isTeacher
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/30'
                  : 'bg-purple-600 text-white shadow-md shadow-purple-500/30'
              }`}
            >
              {isStudent ? (
                <GraduationCap className="w-5 h-5" />
              ) : isTeacher ? (
                <Briefcase className="w-5 h-5" />
              ) : (
                <Shield className="w-5 h-5" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black">
                  {mode === 'login'
                    ? isStudent
                      ? 'Student Login Portal'
                      : isTeacher
                      ? 'Teacher Login Portal'
                      : 'Admin Login'
                    : isStudent
                    ? 'Student Registration'
                    : 'Teacher Registration'}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-white/15 text-white">
                  {role}
                </span>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-300">
            {mode === 'login'
              ? isStudent
                ? 'Sign in to send tuition inquiries, view teacher responses, and contact verified tutors.'
                : isTeacher
                ? 'Sign in to manage tuition requests, edit your hourly fee, and check verification.'
                : 'Administrative system access and teacher verification control.'
              : isStudent
              ? 'Join thousands of students finding verified home and online tutors.'
              : 'Create your teaching profile and receive direct student inquiries.'}
          </p>

          {/* Mode Switcher Tabs */}
          <div className="grid grid-cols-2 gap-1 bg-white/10 p-1 rounded-xl mt-4 text-xs font-bold">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError('');
              }}
              className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                mode === 'login'
                  ? isStudent
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : isTeacher
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Log In</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError('');
                if (role === 'admin') setRole('student');
              }}
              className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                mode === 'register'
                  ? isStudent
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Create Account</span>
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto">
          {/* Explicit Role Portal Switcher */}
          <div className="mb-5">
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Select Login Portal
              </label>
              <span className="text-[11px] text-slate-500 font-medium">Switch between portals</span>
            </div>

            <div className={`grid ${mode === 'login' ? 'grid-cols-3' : 'grid-cols-2'} gap-2`}>
              {/* Student Portal Button */}
              <button
                type="button"
                onClick={() => handleRoleChange('student')}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                  role === 'student'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-800 ring-2 ring-indigo-600/20 shadow-xs'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <GraduationCap className="w-4 h-4 text-indigo-600" />
                  <span>Student Portal</span>
                </div>
                <span className="text-[10px] font-normal text-slate-500">Learners & Parents</span>
              </button>

              {/* Teacher Portal Button */}
              <button
                type="button"
                onClick={() => handleRoleChange('teacher')}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                  role === 'teacher'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-600/20 shadow-xs'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-emerald-600" />
                  <span>Teacher Portal</span>
                </div>
                <span className="text-[10px] font-normal text-slate-500">Tutors & Educators</span>
              </button>

              {/* Admin Button (Login Only) */}
              {mode === 'login' && (
                <button
                  type="button"
                  onClick={() => handleRoleChange('admin')}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                    role === 'admin'
                      ? 'border-purple-600 bg-purple-50 text-purple-800 ring-2 ring-purple-600/20 shadow-xs'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-purple-600" />
                    <span>Admin</span>
                  </div>
                  <span className="text-[10px] font-normal text-slate-500">Control Center</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Demo Credentials Autofill Banner */}
          {mode === 'login' && (
            <div className="mb-4 p-3 bg-slate-50 rounded-2xl border border-slate-200/80 flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                <div>
                  <p className="font-bold text-slate-800">
                    {isStudent
                      ? 'Test as Student (Aarav Patel)'
                      : isTeacher
                      ? 'Test as Verified Teacher (Dr. Sunita)'
                      : 'Test as System Admin'}
                  </p>
                  <p className="text-[11px] text-slate-500">1-Click autofill pre-seeded credentials</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => fillDemoCredentials(role)}
                className={`px-3 py-1.5 rounded-xl font-bold text-xs text-white shadow-xs transition-all ${
                  isStudent
                    ? 'bg-indigo-600 hover:bg-indigo-700'
                    : isTeacher
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-purple-600 hover:bg-purple-700'
                }`}
              >
                Autofill
              </button>
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Login / Register Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder={isStudent ? 'e.g. Rahul Sharma' : 'e.g. Dr. Priya Verma'}
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {isStudent ? 'Student Email Address *' : isTeacher ? 'Teacher Email Address *' : 'Admin Email *'}
              </label>
              <input
                type="email"
                required
                placeholder={
                  isStudent
                    ? 'aarav.patel@student.com'
                    : isTeacher
                    ? 'sunita.kulkarni@example.com'
                    : 'admin@tutorconnect.com'
                }
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-slate-700">Password *</label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => setShowForgotHelper(!showForgotHelper)}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Forgot Password Helper Box */}
            {showForgotHelper && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-1">
                <p className="font-bold flex items-center gap-1">
                  <HelpCircle className="w-3.5 h-3.5 text-amber-600" />
                  <span>Demo Login Password Reference:</span>
                </p>
                <p className="text-[11px] leading-relaxed">
                  • Student: <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">student123</code> (aarav.patel@student.com)<br />
                  • Teacher: <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">teacher123</code> (sunita.kulkarni@example.com)<br />
                  • Admin: <code className="bg-amber-100 px-1 py-0.5 rounded font-mono">admin123</code> (admin@tutorconnect.com)
                </p>
              </div>
            )}

            {/* Remember me option */}
            {mode === 'login' && (
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none text-slate-600">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={e => setRememberMe(e.target.checked)}
                    className="w-3.5 h-3.5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                  <span>Remember my login on this device</span>
                </label>
              </div>
            )}

            {mode === 'register' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Phone Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            )}

            {/* Student Specific Fields upon Registration */}
            {mode === 'register' && isStudent && (
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <p className="text-xs font-bold text-indigo-700 uppercase tracking-wider">
                  Student Learning Requirements
                </p>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Current Class / Grade *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Class 10 CBSE, Class 12 ICSE, IIT-JEE"
                    value={gradeClass}
                    onChange={e => setGradeClass(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Target Subjects *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mathematics, Physics, Chemistry"
                    value={targetSubjects}
                    onChange={e => setTargetSubjects(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">City *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Delhi, Mumbai"
                      value={city}
                      onChange={e => setCity(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Locality</label>
                    <input
                      type="text"
                      placeholder="e.g. Sector 62, Noida"
                      value={location}
                      onChange={e => setLocation(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Teacher Specific Fields upon Registration */}
            {mode === 'register' && isTeacher && (
              <div className="space-y-3 pt-3 border-t border-slate-100">
                <p className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                  Teacher Profile & Qualifications
                </p>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Highest Educational Qualification *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. M.Sc Mathematics, B.Ed, B.Tech, Ph.D"
                    value={qualification}
                    onChange={e => setQualification(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Experience (Years) *</label>
                    <input
                      type="number"
                      min="0"
                      max="40"
                      value={experience}
                      onChange={e => setExperience(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Hourly Fee (₹) *</label>
                    <input
                      type="number"
                      min="100"
                      step="50"
                      value={hourlyFee}
                      onChange={e => setHourlyFee(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Subjects Taught (comma separated) *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mathematics, Physics, Chemistry"
                    value={subjects}
                    onChange={e => setSubjects(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Classes / Grades Handled *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Class 9-10, Class 11-12, IIT-JEE"
                    value={classes}
                    onChange={e => setClasses(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">City / Town *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Delhi, Mumbai"
                      value={city}
                      onChange={e => setCity(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Teaching Mode *</label>
                    <select
                      value={teachingMode}
                      onChange={e => setTeachingMode(e.target.value as TeachingMode)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                    >
                      <option value="both">Both Online & Offline</option>
                      <option value="online">Online Only</option>
                      <option value="offline">Offline / Home Visits</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Location / Locality</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Connaught Place, Central Delhi"
                    value={location}
                    onChange={e => setLocation(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                className={`w-full py-3 rounded-2xl text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 ${
                  isStudent
                    ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200'
                    : isTeacher
                    ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200'
                    : 'bg-purple-600 hover:bg-purple-700 shadow-purple-200'
                }`}
              >
                <span>
                  {mode === 'login'
                    ? isStudent
                      ? 'Sign In as Student'
                      : isTeacher
                      ? 'Sign In as Teacher'
                      : 'Sign In as Administrator'
                    : isStudent
                    ? 'Complete Student Registration'
                    : 'Submit Teacher Application'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Footer Portal Switch Guidance */}
          <div className="mt-5 pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
            {mode === 'login' ? (
              <p>
                Don't have an account yet?{' '}
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className="font-bold text-indigo-600 hover:underline"
                >
                  Create one now
                </button>
              </p>
            ) : (
              <p>
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="font-bold text-indigo-600 hover:underline"
                >
                  Sign in here
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
