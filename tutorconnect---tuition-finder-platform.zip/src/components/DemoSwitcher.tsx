import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Shield, GraduationCap, CheckCircle2, Clock, Users, Database } from 'lucide-react';

interface DemoSwitcherProps {
  onOpenXamppModal: () => void;
}

export const DemoSwitcher: React.FC<DemoSwitcherProps> = ({ onOpenXamppModal }) => {
  const { currentUser, switchDemoUser, resetAllData } = useAuth();

  return (
    <div className="bg-slate-900 text-slate-200 text-xs border-b border-slate-800 py-1.5 px-4 sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 font-semibold text-amber-400 bg-amber-950/70 border border-amber-800/60 px-2 py-0.5 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
            Demo Persona:
          </span>
          <span className="text-slate-300 font-medium">
            {currentUser ? (
              <span className="flex items-center gap-1.5">
                <span className="font-bold text-white">{currentUser.name}</span>
                <span className="capitalize px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 text-[11px] border border-slate-700">
                  {currentUser.role}
                </span>
                {currentUser.isBlocked && (
                  <span className="text-rose-400 font-bold bg-rose-950/80 px-1.5 py-0.5 rounded border border-rose-800">
                    BLOCKED
                  </span>
                )}
              </span>
            ) : (
              <span className="text-slate-400">Guest Visitor</span>
            )}
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-slate-400 hidden sm:inline mr-1">Switch:</span>

          <button
            onClick={() => switchDemoUser('student-1')}
            className={`px-2 py-1 rounded transition-all flex items-center gap-1 font-medium ${
              currentUser?.email === 'aarav.patel@student.com'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
            title="Switch to Student Aarav Patel (Class 11)"
          >
            <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
            <span>Student (Aarav)</span>
          </button>

          <button
            onClick={() => switchDemoUser('teacher-verified')}
            className={`px-2 py-1 rounded transition-all flex items-center gap-1 font-medium ${
              currentUser?.email === 'sunita.kulkarni@example.com'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
            title="Switch to Verified Teacher Dr. Sunita Kulkarni (IIT Delhi)"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Teacher (Dr. Sunita)</span>
          </button>

          <button
            onClick={() => switchDemoUser('teacher-pending')}
            className={`px-2 py-1 rounded transition-all flex items-center gap-1 font-medium ${
              currentUser?.email === 'pooja.iyer@example.com'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
            title="Switch to Teacher Pooja Iyer awaiting admin verification"
          >
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Teacher (Pending)</span>
          </button>

          <button
            onClick={() => switchDemoUser('admin')}
            className={`px-2 py-1 rounded transition-all flex items-center gap-1 font-medium ${
              currentUser?.role === 'admin'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
            title="Switch to System Admin"
          >
            <Shield className="w-3.5 h-3.5 text-purple-400" />
            <span>Admin</span>
          </button>

          <div className="h-4 w-px bg-slate-700 mx-1 hidden sm:block"></div>

          <button
            onClick={onOpenXamppModal}
            className="px-2.5 py-1 rounded bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-semibold flex items-center gap-1.5 shadow-sm transition-all"
            title="View PHP & MySQL Source Code & XAMPP Setup"
          >
            <Database className="w-3.5 h-3.5" />
            <span>PHP / XAMPP Code & SQL</span>
          </button>
        </div>
      </div>
    </div>
  );
};
