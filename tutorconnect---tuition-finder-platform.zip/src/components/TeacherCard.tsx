import React from 'react';
import { TeacherProfile } from '../types';
import {
  ShieldCheck,
  Star,
  MapPin,
  Clock,
  GraduationCap,
  Briefcase,
  Wifi,
  Home,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';

interface TeacherCardProps {
  teacher: TeacherProfile;
  onViewProfile: (teacher: TeacherProfile) => void;
  onRequestTuition: (teacher: TeacherProfile) => void;
}

export const TeacherCard: React.FC<TeacherCardProps> = ({
  teacher,
  onViewProfile,
  onRequestTuition
}) => {
  const isVerified = teacher.verificationStatus === 'verified';

  return (
    <div className="bg-white rounded-2xl border border-slate-200 hover:border-indigo-300 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between overflow-hidden group">
      <div className="p-6">
        {/* Top Header: Avatar + Main Info */}
        <div className="flex items-start gap-4">
          <div className="relative shrink-0">
            <img
              src={teacher.avatarUrl}
              alt={teacher.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-100 shadow-sm group-hover:scale-105 transition-transform"
            />
            {isVerified && (
              <span
                className="absolute -bottom-1 -right-1 bg-emerald-600 text-white p-1 rounded-full shadow-sm ring-2 ring-white"
                title="Verified Teacher: Credentials verified by Admin"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
              </span>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors truncate">
                {teacher.name}
              </h3>
              {isVerified ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Verified
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">
                  Verification Pending
                </span>
              )}
            </div>

            <p className="text-xs font-medium text-slate-600 flex items-center gap-1.5 mt-1 line-clamp-1">
              <GraduationCap className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span>{teacher.qualification}</span>
            </p>

            <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-500">
              <span className="flex items-center gap-1">
                <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                {teacher.experience} yrs exp
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {teacher.city}
              </span>
            </div>
          </div>
        </div>

        {/* Subjects & Classes Pills */}
        <div className="mt-4 space-y-2">
          <div className="flex flex-wrap gap-1.5">
            {teacher.subjects.slice(0, 4).map((sub, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 rounded-md text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100"
              >
                {sub}
              </span>
            ))}
            {teacher.subjects.length > 4 && (
              <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-slate-100 text-slate-600">
                +{teacher.subjects.length - 4} more
              </span>
            )}
          </div>

          <div className="flex flex-wrap gap-1">
            {teacher.classes.slice(0, 3).map((cls, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-600"
              >
                {cls}
              </span>
            ))}
          </div>
        </div>

        {/* Bio Excerpt */}
        <p className="mt-3 text-xs text-slate-600 line-clamp-2 leading-relaxed">
          {teacher.about}
        </p>

        {/* Teaching Mode & Availability */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1 font-medium">
            {teacher.teachingMode === 'online' ? (
              <span className="flex items-center gap-1 text-sky-700 bg-sky-50 px-2 py-0.5 rounded">
                <Wifi className="w-3 h-3 text-sky-500" /> Online Only
              </span>
            ) : teacher.teachingMode === 'offline' ? (
              <span className="flex items-center gap-1 text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                <Home className="w-3 h-3 text-amber-600" /> Offline / Home
              </span>
            ) : (
              <span className="flex items-center gap-1 text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                <Wifi className="w-3 h-3 text-indigo-500" />
                <Home className="w-3 h-3 text-indigo-500" />
                Online & Home
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 text-amber-500 font-bold">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{teacher.rating.toFixed(1)}</span>
            <span className="text-slate-400 font-normal">({teacher.reviewCount})</span>
          </div>
        </div>
      </div>

      {/* Card Footer: Pricing & Action Buttons */}
      <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex items-center justify-between gap-3">
        <div>
          <div className="flex items-baseline gap-1">
            <span className="text-lg font-extrabold text-slate-900">₹{teacher.hourlyFee}</span>
            <span className="text-xs text-slate-500 font-medium">/hr</span>
          </div>
          <span className="text-[11px] text-slate-500 block">
            ₹{teacher.monthlyFee}/mo (approx)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onViewProfile(teacher)}
            className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:text-indigo-600 hover:bg-white border border-slate-200 hover:border-indigo-200 transition-all shadow-xs"
          >
            Profile
          </button>
          <button
            onClick={() => onRequestTuition(teacher)}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm shadow-indigo-200 flex items-center gap-1.5 transition-all group-hover:scale-102"
          >
            <span>Request Tuition</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
