import React from 'react';
import { GraduationCap, ShieldCheck, Mail, Phone, PhoneCall, MapPin, Database, Award, BookOpen, Headphones, MessageSquare } from 'lucide-react';

interface FooterProps {
  onSelectTab: (tab: 'home' | 'search' | 'dashboard' | 'admin') => void;
  onOpenXamppModal: () => void;
  onOpenHelpline: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectTab, onOpenXamppModal, onOpenHelpline }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-slate-800">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md">
                <GraduationCap className="w-5 h-5" />
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight">
                Tutor<span className="text-indigo-400">Connect</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              TutorConnect is India’s dedicated student–teacher tuition discovery platform. We connect learners with qualified, background-checked home and online private tutors across all academic subjects and competitive exam boards.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-400 text-xs font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                100% Verified Teachers
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-950/80 border border-indigo-800 text-indigo-400 text-xs font-semibold">
                <Award className="w-3.5 h-3.5" />
                Admin Certified
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase">Platform</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onSelectTab('home')} className="hover:text-indigo-400 transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('search')} className="hover:text-indigo-400 transition-colors">
                  Find a Private Tutor
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('dashboard')} className="hover:text-indigo-400 transition-colors">
                  Student Portal
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('dashboard')} className="hover:text-indigo-400 transition-colors">
                  Teacher Portal
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('admin')} className="hover:text-indigo-400 transition-colors">
                  Admin Verification
                </button>
              </li>
            </ul>
          </div>

          {/* Subjects */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase">Top Subjects</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>Mathematics & Calculus</li>
              <li>Physics & Mechanics</li>
              <li>Chemistry (Organic/Inorganic)</li>
              <li>Computer Science & Python</li>
              <li>English Literature & CELTA</li>
              <li>Biology & NEET Prep</li>
            </ul>
          </div>

          {/* Tech Stack & XAMPP */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase">XAMPP Package</h4>
            <p className="text-xs text-slate-400">
              Complete PHP + MySQL source code, SQL database dump, and step-by-step setup guides ready for local deployment.
            </p>
            <button
              onClick={onOpenXamppModal}
              className="mt-2 w-full py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-indigo-300 hover:text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 border border-slate-700 transition-all"
            >
              <Database className="w-4 h-4 text-sky-400" />
              <span>Get PHP & SQL Files</span>
            </button>
          </div>
        </div>

        {/* Helpline Banner in Footer */}
        <div className="my-8 p-5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-indigo-950/60 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-12 h-12 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shrink-0 shadow-md">
              <Headphones className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h4 className="font-extrabold text-white text-base">TutorConnect Academic Helpline</h4>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                  All-India Toll-Free
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Dial <strong className="text-amber-400 font-mono">1800-889-2026</strong> for free teacher match guidance, verification help & student counseling.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="tel:18008892026"
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-md transition-all"
            >
              <PhoneCall className="w-3.5 h-3.5 fill-slate-950" />
              <span>Call 1800-889-2026</span>
            </a>
            <button
              onClick={onOpenHelpline}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/20 transition-all cursor-pointer"
            >
              Helpline Center
            </button>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} TutorConnect Platform. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              PHP 8.2 & MySQL Ready
            </span>
            <span>Apache / XAMPP Compatible</span>
            <span>Strict Role-Based Access Control</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
