import React, { useState } from 'react';
import { TeacherProfile, TeachingMode } from '../types';
import { useAuth } from '../context/AuthContext';
import { X, Send, CheckCircle2, AlertCircle, Sparkles, GraduationCap } from 'lucide-react';

interface SendRequestModalProps {
  teacher: TeacherProfile | null;
  onClose: () => void;
  onSuccess: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const SendRequestModal: React.FC<SendRequestModalProps> = ({
  teacher,
  onClose,
  onSuccess,
  onOpenAuth
}) => {
  const { currentUser, sendTuitionRequest, switchDemoUser } = useAuth();

  const [subject, setSubject] = useState(teacher?.subjects[0] || 'Mathematics');
  const [teachingMode, setTeachingMode] = useState<TeachingMode>(
    teacher?.teachingMode === 'both' ? 'online' : (teacher?.teachingMode || 'online')
  );
  const [preferredTimings, setPreferredTimings] = useState(
    teacher?.availableTimings[0] || 'Weekday Evenings (5:00 PM - 7:00 PM)'
  );
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!teacher) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!currentUser) {
      setError('You must be logged in as a student to send a tuition request.');
      return;
    }

    if (currentUser.role !== 'student') {
      setError(`You are currently logged in as a ${currentUser.role}. Please switch to a Student account.`);
      return;
    }

    if (!subject) {
      setError('Please select a subject.');
      return;
    }

    if (!message.trim()) {
      setError('Please enter a brief message describing your learning goals or requirements.');
      return;
    }

    const result = sendTuitionRequest({
      teacherId: teacher.id,
      teacherName: teacher.name,
      teacherAvatar: teacher.avatarUrl,
      subject,
      teachingMode,
      preferredTimings,
      studentMessage: message.trim()
    });

    if (result.success) {
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        onSuccess();
        onClose();
      }, 1600);
    } else {
      setError(result.error || 'Failed to send request.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-slate-900 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-4">
            <img
              src={teacher.avatarUrl}
              alt={teacher.name}
              className="w-14 h-14 rounded-2xl object-cover ring-2 ring-indigo-500 shadow-md"
            />
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-indigo-400">
                Send Tuition Request
              </span>
              <h2 className="text-xl font-bold">{teacher.name}</h2>
              <p className="text-xs text-slate-300">
                ₹{teacher.hourlyFee}/hr • {teacher.qualification}
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {isSubmitted ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto animate-bounce">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">Tuition Request Sent!</h3>
              <p className="text-sm text-slate-600 max-w-xs mx-auto">
                Teacher {teacher.name} has received your request. You can track status in your Student Dashboard.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* If not logged in as student notification */}
              {(!currentUser || currentUser.role !== 'student') && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs space-y-2">
                  <div className="flex items-start gap-2 text-amber-800">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>
                      You must be signed in as a <strong>Student</strong> to send requests.
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => switchDemoUser('student-1')}
                      className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs flex items-center gap-1 shadow-xs"
                    >
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>1-Click Switch to Student (Aarav)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenAuth('login')}
                      className="text-xs text-indigo-700 font-semibold underline hover:text-indigo-900"
                    >
                      Or Log in
                    </button>
                  </div>
                </div>
              )}

              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Subject Dropdown */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Subject Required *
                </label>
                <select
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden bg-white"
                >
                  {teacher.subjects.map((sub, idx) => (
                    <option key={idx} value={sub}>
                      {sub}
                    </option>
                  ))}
                </select>
              </div>

              {/* Teaching Mode */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Preferred Tuition Mode *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: 'online', label: 'Online' },
                    { value: 'offline', label: 'Home / Offline' },
                    { value: 'both', label: 'Either' }
                  ].map(option => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setTeachingMode(option.value as TeachingMode)}
                      className={`py-2 px-3 rounded-xl text-xs font-semibold border transition-all text-center ${
                        teachingMode === option.value
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Preferred Timings */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Preferred Timings / Slot
                </label>
                <input
                  type="text"
                  value={preferredTimings}
                  onChange={e => setPreferredTimings(e.target.value)}
                  placeholder="e.g. Weekday evenings, Saturday mornings"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Your Requirements & Learning Goals *
                </label>
                <textarea
                  rows={3}
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="Tell the teacher your current class, specific chapters you need help with, target exam dates, etc."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-200 flex items-center gap-2 transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Request</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
