/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { DemoSwitcher } from './components/DemoSwitcher';
import { HomePage } from './pages/HomePage';
import { SearchTutorsPage } from './pages/SearchTutorsPage';
import { StudentDashboard } from './pages/StudentDashboard';
import { TeacherDashboard } from './pages/TeacherDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { TeacherProfileModal } from './components/TeacherProfileModal';
import { SendRequestModal } from './components/SendRequestModal';
import { AuthModal } from './components/AuthModal';
import { XamppExportModal } from './components/XamppExportModal';
import { HelplineModal } from './components/HelplineModal';
import { PhoneCall } from 'lucide-react';
import { TeacherProfile, SearchFilterState, UserRole } from './types';

function MainApp() {
  const { currentUser } = useAuth();

  const [currentTab, setCurrentTab] = useState<'home' | 'search' | 'dashboard' | 'admin'>('home');
  const [searchPreFilters, setSearchPreFilters] = useState<Partial<SearchFilterState>>({});

  // Modals state
  const [viewingTeacher, setViewingTeacher] = useState<TeacherProfile | null>(null);
  const [requestingTeacher, setRequestingTeacher] = useState<TeacherProfile | null>(null);
  const [authModalState, setAuthModalState] = useState<{
    isOpen: boolean;
    mode: 'login' | 'register';
    role: UserRole;
  }>({
    isOpen: false,
    mode: 'login',
    role: 'student'
  });
  const [isXamppModalOpen, setIsXamppModalOpen] = useState(false);
  const [isHelplineOpen, setIsHelplineOpen] = useState(false);

  const handleOpenAuth = (mode: 'login' | 'register' = 'login', role: UserRole = 'student') => {
    setAuthModalState({ isOpen: true, mode, role });
  };

  const handleSearchFromHome = (params: { subject?: string; classGrade?: string; location?: string }) => {
    setSearchPreFilters({
      subject: params.subject || '',
      classGrade: params.classGrade || '',
      location: params.location || '',
      searchQuery: ''
    });
    setCurrentTab('search');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* 1-Click Interactive Persona Switcher Banner */}
      <DemoSwitcher onOpenXamppModal={() => setIsXamppModalOpen(true)} />

      {/* Main Navigation */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={tab => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAuth={handleOpenAuth}
        onOpenXamppModal={() => setIsXamppModalOpen(true)}
        onOpenHelpline={() => setIsHelplineOpen(true)}
      />

      {/* Active Page View */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <HomePage
            onSearchSubmit={handleSearchFromHome}
            onViewTeacherProfile={teacher => setViewingTeacher(teacher)}
            onRequestTuition={teacher => setRequestingTeacher(teacher)}
            onOpenAuth={handleOpenAuth}
            onOpenXamppModal={() => setIsXamppModalOpen(true)}
            onOpenHelpline={() => setIsHelplineOpen(true)}
          />
        )}

        {currentTab === 'search' && (
          <SearchTutorsPage
            initialFilters={searchPreFilters}
            onViewTeacherProfile={teacher => setViewingTeacher(teacher)}
            onRequestTuition={teacher => setRequestingTeacher(teacher)}
          />
        )}

        {currentTab === 'dashboard' && (
          <>
            {!currentUser ? (
              <div className="max-w-2xl mx-auto py-16 px-4 space-y-6 text-center">
                <div>
                  <h2 className="text-2xl font-black text-slate-900">Sign In to TutorConnect</h2>
                  <p className="text-sm text-slate-500 mt-1">
                    Select your portal to access your customized dashboard, requests, and schedules.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                  {/* Student Portal Card */}
                  <div className="p-6 rounded-3xl bg-white border-2 border-indigo-100 shadow-lg hover:border-indigo-300 transition-all flex flex-col justify-between">
                    <div>
                      <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold mb-3">
                        🎓
                      </div>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600">
                        Student Portal
                      </span>
                      <h3 className="font-bold text-slate-900 text-base mt-0.5">Students & Parents</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Track tuition inquiries, view teacher responses, and contact verified teachers.
                      </p>
                    </div>

                    <div className="pt-5 space-y-2">
                      <button
                        onClick={() => handleOpenAuth('login', 'student')}
                        className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-200 transition-all"
                      >
                        Student Login
                      </button>
                      <button
                        onClick={() => handleOpenAuth('register', 'student')}
                        className="w-full py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-xs transition-colors"
                      >
                        Sign Up as Student
                      </button>
                    </div>
                  </div>

                  {/* Teacher Portal Card */}
                  <div className="p-6 rounded-3xl bg-white border-2 border-emerald-100 shadow-lg hover:border-emerald-300 transition-all flex flex-col justify-between">
                    <div>
                      <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold mb-3">
                        💼
                      </div>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-600">
                        Teacher Portal
                      </span>
                      <h3 className="font-bold text-slate-900 text-base mt-0.5">Teachers & Educators</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Accept student inquiries, showcase verified badge, and manage lesson rates.
                      </p>
                    </div>

                    <div className="pt-5 space-y-2">
                      <button
                        onClick={() => handleOpenAuth('login', 'teacher')}
                        className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-200 transition-all"
                      >
                        Teacher Login
                      </button>
                      <button
                        onClick={() => handleOpenAuth('register', 'teacher')}
                        className="w-full py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs transition-colors"
                      >
                        Join as Teacher
                      </button>
                    </div>
                  </div>
                </div>

                <div className="text-xs text-slate-400 pt-2">
                  <span>Are you an administrator? </span>
                  <button
                    onClick={() => handleOpenAuth('login', 'admin')}
                    className="font-bold text-purple-600 hover:underline"
                  >
                    Admin Sign In
                  </button>
                </div>
              </div>
            ) : currentUser.role === 'admin' ? (
              <AdminDashboard />
            ) : currentUser.role === 'teacher' ? (
              <TeacherDashboard />
            ) : (
              <StudentDashboard onFindTutors={() => setCurrentTab('search')} />
            )}
          </>
        )}

        {currentTab === 'admin' && (
          <>
            {currentUser?.role === 'admin' ? (
              <AdminDashboard />
            ) : (
              <div className="max-w-lg mx-auto py-20 px-4 text-center space-y-4">
                <h2 className="text-2xl font-bold text-slate-800">Admin Authentication Required</h2>
                <p className="text-sm text-slate-600">
                  Please log in with administrator credentials (<code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-700">admin@tutorconnect.com</code> / <code className="bg-slate-100 px-1 py-0.5 rounded text-indigo-700">admin123</code>).
                </p>
                <button
                  onClick={() => handleOpenAuth('login', 'admin')}
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs"
                >
                  Admin Sign In
                </button>
              </div>
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onSelectTab={tab => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenXamppModal={() => setIsXamppModalOpen(true)}
        onOpenHelpline={() => setIsHelplineOpen(true)}
      />

      {/* Floating 24x7 Helpline Widget */}
      <div className="fixed bottom-5 right-5 z-40">
        <button
          onClick={() => setIsHelplineOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-slate-950 font-black text-xs shadow-2xl shadow-amber-500/40 hover:shadow-amber-500/60 hover:scale-105 transition-all duration-300 border-2 border-white/90 cursor-pointer"
          title="Open TutorConnect Academic Helpline (1800-889-2026)"
        >
          <div className="relative">
            <PhoneCall className="w-4 h-4 fill-slate-950 animate-bounce-subtle" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-white animate-pulse"></span>
          </div>
          <span className="font-extrabold tracking-tight">Helpline: 1800-889-2026</span>
        </button>
      </div>

      {/* Modals */}
      {viewingTeacher && (
        <TeacherProfileModal
          teacher={viewingTeacher}
          onClose={() => setViewingTeacher(null)}
          onRequestTuition={teacher => setRequestingTeacher(teacher)}
        />
      )}

      {requestingTeacher && (
        <SendRequestModal
          teacher={requestingTeacher}
          onClose={() => setRequestingTeacher(null)}
          onSuccess={() => {
            setCurrentTab('dashboard');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onOpenAuth={handleOpenAuth}
        />
      )}

      <AuthModal
        isOpen={authModalState.isOpen}
        initialMode={authModalState.mode}
        initialRole={authModalState.role}
        onClose={() => setAuthModalState(prev => ({ ...prev, isOpen: false }))}
        onSuccess={() => {
          setCurrentTab('dashboard');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {isXamppModalOpen && (
        <XamppExportModal onClose={() => setIsXamppModalOpen(false)} />
      )}

      <HelplineModal
        isOpen={isHelplineOpen}
        onClose={() => setIsHelplineOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
