import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { TeacherProfile } from '../types';
import { POPULAR_SUBJECTS, POPULAR_CLASSES, POPULAR_CITIES } from '../data/mockData';
import { TeacherCard } from '../components/TeacherCard';
import {
  AnimatedStudentAvatar,
  DEFAULT_ANIMATED_STUDENT_AVATAR,
  DEFAULT_ANIMATED_STUDENT_SNEHA
} from '../components/AnimatedStudentAvatar';
import {
  Search,
  MapPin,
  BookOpen,
  GraduationCap,
  Briefcase,
  LogIn,
  ShieldCheck,
  CheckCircle2,
  Users,
  Award,
  Sparkles,
  ArrowRight,
  Clock,
  Compass,
  Star,
  FileCheck2,
  PhoneCall,
  Palette,
  Check,
  Headphones
} from 'lucide-react';

export type FrontPageColorTheme = 'sapphire-gold' | 'emerald-teal' | 'sunset-crimson' | 'ocean-blue';

interface ThemeConfig {
  id: FrontPageColorTheme;
  name: string;
  shortName: string;
  dotBg: string;
  heroBg: string;
  ambientLight1: string;
  ambientLight2: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  titleGradient: string;
  searchBtnBg: string;
  searchBtnText: string;
  searchBtnShadow: string;
  accentText: string;
  accentBg: string;
  accentBorder: string;
  statCardBg: string;
  safetyBannerBg: string;
}

const THEMES: Record<FrontPageColorTheme, ThemeConfig> = {
  'sapphire-gold': {
    id: 'sapphire-gold',
    name: 'Royal Sapphire & Saffron Gold',
    shortName: 'Sapphire & Gold',
    dotBg: 'bg-gradient-to-r from-blue-600 to-amber-500',
    heroBg: 'bg-gradient-to-br from-[#070e28] via-[#10194e] to-[#0a0f29]',
    ambientLight1: 'bg-amber-500/15',
    ambientLight2: 'bg-blue-600/20',
    badgeBg: 'bg-amber-500/15',
    badgeText: 'text-amber-300',
    badgeBorder: 'border-amber-400/30',
    titleGradient: 'from-amber-300 via-orange-200 to-sky-300',
    searchBtnBg: 'bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 hover:from-amber-600 hover:to-orange-700',
    searchBtnText: 'text-slate-950 font-black',
    searchBtnShadow: 'shadow-amber-500/30',
    accentText: 'text-amber-600',
    accentBg: 'bg-amber-50',
    accentBorder: 'border-amber-200',
    statCardBg: 'bg-white/10 border-white/15',
    safetyBannerBg: 'bg-gradient-to-br from-[#0c163b] via-[#152357] to-[#0a102b]'
  },
  'emerald-teal': {
    id: 'emerald-teal',
    name: 'Vedic Emerald & Oasis Mint',
    shortName: 'Emerald & Mint',
    dotBg: 'bg-gradient-to-r from-emerald-500 to-teal-400',
    heroBg: 'bg-gradient-to-br from-[#022c22] via-[#064e3b] to-[#03201a]',
    ambientLight1: 'bg-emerald-400/20',
    ambientLight2: 'bg-teal-500/20',
    badgeBg: 'bg-emerald-400/15',
    badgeText: 'text-emerald-300',
    badgeBorder: 'border-emerald-400/30',
    titleGradient: 'from-emerald-300 via-teal-200 to-amber-200',
    searchBtnBg: 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-600 hover:to-teal-600',
    searchBtnText: 'text-white font-extrabold',
    searchBtnShadow: 'shadow-emerald-500/30',
    accentText: 'text-emerald-700',
    accentBg: 'bg-emerald-50',
    accentBorder: 'border-emerald-200',
    statCardBg: 'bg-white/10 border-emerald-400/20',
    safetyBannerBg: 'bg-gradient-to-br from-[#042f2e] via-[#064e3b] to-[#022018]'
  },
  'sunset-crimson': {
    id: 'sunset-crimson',
    name: 'Sunset Coral & Royal Violet',
    shortName: 'Sunset & Coral',
    dotBg: 'bg-gradient-to-r from-rose-500 via-pink-500 to-amber-500',
    heroBg: 'bg-gradient-to-br from-[#2a0845] via-[#480c2e] to-[#180416]',
    ambientLight1: 'bg-rose-500/25',
    ambientLight2: 'bg-amber-500/20',
    badgeBg: 'bg-rose-500/20',
    badgeText: 'text-rose-200',
    badgeBorder: 'border-rose-400/40',
    titleGradient: 'from-amber-200 via-rose-200 to-pink-300',
    searchBtnBg: 'bg-gradient-to-r from-rose-500 via-pink-600 to-amber-500 hover:from-rose-600 hover:to-amber-600',
    searchBtnText: 'text-white font-extrabold',
    searchBtnShadow: 'shadow-rose-500/40',
    accentText: 'text-rose-600',
    accentBg: 'bg-rose-50',
    accentBorder: 'border-rose-200',
    statCardBg: 'bg-white/10 border-rose-300/20',
    safetyBannerBg: 'bg-gradient-to-br from-[#3b084e] via-[#540d34] to-[#20061d]'
  },
  'ocean-blue': {
    id: 'ocean-blue',
    name: 'Electric Ocean & Cyan Breeze',
    shortName: 'Ocean & Cyan',
    dotBg: 'bg-gradient-to-r from-sky-400 to-blue-600',
    heroBg: 'bg-gradient-to-br from-[#0c2d48] via-[#145374] to-[#0b1b2b]',
    ambientLight1: 'bg-sky-400/20',
    ambientLight2: 'bg-cyan-500/20',
    badgeBg: 'bg-sky-400/15',
    badgeText: 'text-sky-300',
    badgeBorder: 'border-sky-400/30',
    titleGradient: 'from-cyan-300 via-sky-200 to-blue-200',
    searchBtnBg: 'bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700',
    searchBtnText: 'text-slate-950 font-black',
    searchBtnShadow: 'shadow-cyan-500/30',
    accentText: 'text-sky-700',
    accentBg: 'bg-sky-50',
    accentBorder: 'border-sky-200',
    statCardBg: 'bg-white/10 border-sky-400/20',
    safetyBannerBg: 'bg-gradient-to-br from-[#0b253a] via-[#103e5c] to-[#071624]'
  }
};

interface HomePageProps {
  onSearchSubmit: (params: { subject?: string; classGrade?: string; location?: string }) => void;
  onViewTeacherProfile: (teacher: TeacherProfile) => void;
  onRequestTuition: (teacher: TeacherProfile) => void;
  onOpenAuth: (mode: 'login' | 'register', role?: 'student' | 'teacher') => void;
  onOpenXamppModal: () => void;
  onOpenHelpline: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onSearchSubmit,
  onViewTeacherProfile,
  onRequestTuition,
  onOpenAuth,
  onOpenXamppModal,
  onOpenHelpline
}) => {
  const { allTeachers } = useAuth();

  const [heroSubject, setHeroSubject] = useState('');
  const [heroClass, setHeroClass] = useState('');
  const [heroLocation, setHeroLocation] = useState('');

  // Active front page color theme with localStorage persistence (defaults to Sunset & Coral)
  const [themeId, setThemeId] = useState<FrontPageColorTheme>(() => {
    const saved = localStorage.getItem('tutorconnect_front_theme_v3');
    if (saved && saved in THEMES) return saved as FrontPageColorTheme;
    return 'sunset-crimson';
  });

  const currentTheme = THEMES[themeId] || THEMES['sunset-crimson'];

  const handleSelectTheme = (newTheme: FrontPageColorTheme) => {
    setThemeId(newTheme);
    localStorage.setItem('tutorconnect_front_theme_v3', newTheme);
  };

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchSubmit({
      subject: heroSubject,
      classGrade: heroClass,
      location: heroLocation
    });
  };

  // Featured verified teachers
  const featuredTeachers = allTeachers
    .filter(t => t.verificationStatus === 'verified' && !t.isBlocked)
    .slice(0, 3);

  return (
    <div className="space-y-20 pb-20 transition-colors duration-500">
      {/* Hero Section with Dynamic Theme Palette */}
      <section className={`relative overflow-hidden ${currentTheme.heroBg} text-white pt-12 pb-24 px-4 sm:px-6 lg:px-8 transition-all duration-700`}>
        {/* Background ambient lighting */}
        <div className={`absolute top-0 left-1/4 w-96 h-96 ${currentTheme.ambientLight1} blur-3xl pointer-events-none rounded-full`}></div>
        <div className={`absolute top-20 right-1/4 w-96 h-96 ${currentTheme.ambientLight2} blur-3xl pointer-events-none rounded-full`}></div>

        {/* Live Color Theme Switcher Bar */}
        <div className="max-w-5xl mx-auto flex items-center justify-center relative z-20 mb-6">
          <div className="inline-flex items-center gap-2 p-1.5 px-3 rounded-full bg-slate-900/80 border border-white/20 backdrop-blur-md shadow-xl text-xs">
            <span className="flex items-center gap-1.5 text-slate-300 font-bold pl-1 text-[11px]">
              <Palette className="w-3.5 h-3.5 text-amber-400" />
              <span>Front Page Color:</span>
            </span>

            <div className="flex items-center gap-1">
              {(Object.keys(THEMES) as FrontPageColorTheme[]).map(key => {
                const t = THEMES[key];
                const isSelected = themeId === key;
                return (
                  <button
                    key={key}
                    onClick={() => handleSelectTheme(key)}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold transition-all ${
                      isSelected
                        ? 'bg-white text-slate-950 shadow-md ring-2 ring-white/50 scale-105'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                    title={t.name}
                  >
                    <span className={`w-2.5 h-2.5 rounded-full ${t.dotBg}`}></span>
                    <span>{t.shortName}</span>
                    {isSelected && <Check className="w-3 h-3 text-slate-950 stroke-[3]" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
          <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full ${currentTheme.badgeBg} border ${currentTheme.badgeBorder} ${currentTheme.badgeText} text-xs font-bold backdrop-blur-md shadow-xs`}>
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>India's Leading Student–Teacher Tuition Finder</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
            Find the Best <span className={`bg-gradient-to-r ${currentTheme.titleGradient} bg-clip-text text-transparent`}>Verified Private Tutors</span> for Home & Online Classes
          </h1>

          <p className="text-base sm:text-lg text-slate-200 max-w-3xl mx-auto font-normal leading-relaxed">
            Connect directly with qualified educators for CBSE, ICSE, State Boards, IIT-JEE, and NEET. No mediator fees, verified qualifications, and flexible timings.
          </p>

          {/* Quick Search Form Box */}
          <div className="pt-6 max-w-4xl mx-auto">
            <form
              onSubmit={handleHeroSearch}
              className="bg-white p-3 rounded-2xl sm:rounded-3xl shadow-2xl border-2 border-white/60 grid grid-cols-1 sm:grid-cols-12 gap-2 text-slate-800 text-left"
            >
              {/* Subject Field */}
              <div className="sm:col-span-4 p-2 sm:border-r border-slate-200 flex items-center gap-3">
                <BookOpen className="w-5 h-5 text-indigo-600 shrink-0" />
                <div className="w-full">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={heroSubject}
                    onChange={e => setHeroSubject(e.target.value)}
                    placeholder="e.g. Mathematics, Physics"
                    className="w-full text-xs sm:text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden bg-transparent"
                  />
                </div>
              </div>

              {/* Class/Grade Field */}
              <div className="sm:col-span-3 p-2 sm:border-r border-slate-200 flex items-center gap-3">
                <GraduationCap className="w-5 h-5 text-indigo-600 shrink-0" />
                <div className="w-full">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Class / Grade
                  </label>
                  <input
                    type="text"
                    value={heroClass}
                    onChange={e => setHeroClass(e.target.value)}
                    placeholder="e.g. Class 10, IIT-JEE"
                    className="w-full text-xs sm:text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden bg-transparent"
                  />
                </div>
              </div>

              {/* Location/City Field */}
              <div className="sm:col-span-3 p-2 flex items-center gap-3">
                <MapPin className="w-5 h-5 text-indigo-600 shrink-0" />
                <div className="w-full">
                  <label className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    City / Locality
                  </label>
                  <input
                    type="text"
                    value={heroLocation}
                    onChange={e => setHeroLocation(e.target.value)}
                    placeholder="e.g. Delhi, Mumbai, Bengaluru"
                    className="w-full text-xs sm:text-sm font-semibold text-slate-800 placeholder-slate-400 focus:outline-hidden bg-transparent"
                  />
                </div>
              </div>

              {/* Search Button Styled with Theme */}
              <div className="sm:col-span-2 flex items-center">
                <button
                  type="submit"
                  className={`w-full h-full py-3.5 px-4 rounded-xl sm:rounded-2xl ${currentTheme.searchBtnBg} ${currentTheme.searchBtnText} text-xs font-bold flex items-center justify-center gap-2 shadow-lg ${currentTheme.searchBtnShadow} transition-all hover:scale-102`}
                >
                  <Search className="w-4 h-4 stroke-[2.5]" />
                  <span>Search</span>
                </button>
              </div>
            </form>
          </div>

          {/* Quick Popular Searches */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-300">
            <span className="text-slate-400 flex items-center gap-1 font-medium">
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              Popular:
            </span>
            {['Mathematics', 'Physics', 'IIT-JEE', 'NEET Prep', 'Class 10 CBSE', 'English'].map(tag => (
              <button
                key={tag}
                onClick={() => onSearchSubmit({ subject: tag })}
                className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-white font-medium transition-colors"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Live Key Highlights Counter Bar */}
        <div className="max-w-4xl mx-auto mt-12 grid grid-cols-2 md:grid-cols-4 gap-3 text-center relative z-10">
          <div className={`p-4 rounded-2xl ${currentTheme.statCardBg} backdrop-blur-md`}>
            <p className="text-2xl sm:text-3xl font-black text-white">{allTeachers.length}+</p>
            <p className="text-xs text-slate-200 mt-1 flex items-center justify-center gap-1">
              <Users className="w-3.5 h-3.5 text-amber-400" />
              Verified Teachers
            </p>
          </div>
          <div className={`p-4 rounded-2xl ${currentTheme.statCardBg} backdrop-blur-md`}>
            <p className="text-2xl sm:text-3xl font-black text-white">100%</p>
            <p className="text-xs text-slate-200 mt-1 flex items-center justify-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Direct Contacts
            </p>
          </div>
          <div className={`p-4 rounded-2xl ${currentTheme.statCardBg} backdrop-blur-md`}>
            <p className="text-2xl sm:text-3xl font-black text-white">10+ Cities</p>
            <p className="text-xs text-slate-200 mt-1 flex items-center justify-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-sky-400" />
              Home & Online Tutors
            </p>
          </div>
          <div className={`p-4 rounded-2xl ${currentTheme.statCardBg} backdrop-blur-md`}>
            <p className="text-2xl sm:text-3xl font-black text-white">4.9 / 5.0</p>
            <p className="text-xs text-slate-200 mt-1 flex items-center justify-center gap-1">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              Satisfaction Rating
            </p>
          </div>
        </div>
      </section>

      {/* Direct Portal Access: Student & Teacher Login Hub */}
      <section className="max-w-6xl mx-auto px-4 -mt-10 sm:-mt-12 relative z-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Student Login Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border-2 border-indigo-100 shadow-xl hover:shadow-2xl hover:border-indigo-300 transition-all flex flex-col sm:flex-row items-center justify-between gap-5 group">
            <div className="flex items-center gap-4 text-center sm:text-left">
              <div className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-200/80 flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm shrink-0">
                <GraduationCap className="w-7 h-7" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                  Student Portal
                </span>
                <h3 className="font-extrabold text-slate-900 text-lg mt-1">Student & Parent Login</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Track tuition requests, review teacher replies & start classes.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => onOpenAuth('login', 'student')}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-200 shrink-0 transition-all hover:scale-102"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Student Login</span>
              </button>
              <button
                onClick={() => onOpenAuth('register', 'student')}
                className="px-3 py-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs shrink-0 transition-colors"
                title="Create Student Account"
              >
                Sign Up
              </button>
            </div>
          </div>

          {/* Teacher Login Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border-2 border-emerald-100 shadow-xl hover:shadow-2xl hover:border-emerald-300 transition-all flex flex-col sm:flex-row items-center justify-between gap-5 group">
            <div className="flex items-center gap-4 text-center sm:text-left">
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all shadow-sm shrink-0">
                <Briefcase className="w-7 h-7" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                  Teacher Portal
                </span>
                <h3 className="font-extrabold text-slate-900 text-lg mt-1">Teacher & Tutor Login</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Respond to student inquiries, view verified badge & set fees.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={() => onOpenAuth('login', 'teacher')}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-200 shrink-0 transition-all hover:scale-102"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Teacher Login</span>
              </button>
              <button
                onClick={() => onOpenAuth('register', 'teacher')}
                className="px-3 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs shrink-0 transition-colors"
                title="Register as Teacher"
              >
                Join
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Subjects Carousel / Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className={`text-xs font-bold uppercase tracking-wider ${currentTheme.accentText}`}>
              Browse Categories
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
              Popular Academic Subjects
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Find specialized tuition from foundational schooling to competitive entrance exams.
            </p>
          </div>
          <button
            onClick={() => onSearchSubmit({})}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>Explore all subjects</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {POPULAR_SUBJECTS.map((sub, idx) => (
            <button
              key={idx}
              onClick={() => onSearchSubmit({ subject: sub })}
              className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-400 hover:shadow-lg transition-all text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                <BookOpen className="w-5 h-5" />
              </div>
              <p className="font-bold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors">
                {sub}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">Tutors available</p>
            </button>
          ))}
        </div>
      </section>

      {/* Featured Verified Teachers */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Admin Verified Educators
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900">
              Featured High-Rated Tutors
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Top reviewed tutors with verified degrees, proven pedagogy, and track records.
            </p>
          </div>

          <button
            onClick={() => onSearchSubmit({})}
            className="px-4 py-2 rounded-xl text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 flex items-center gap-1.5 transition-colors"
          >
            <span>View All Tutors ({allTeachers.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredTeachers.map(teacher => (
            <TeacherCard
              key={teacher.id}
              teacher={teacher}
              onViewProfile={onViewTeacherProfile}
              onRequestTuition={onRequestTuition}
            />
          ))}
        </div>
      </section>

      {/* How It Works (For Students and For Teachers) */}
      <section className="bg-slate-100/80 py-16 px-4 sm:px-6 lg:px-8 border-y border-slate-200">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className={`text-xs font-bold uppercase tracking-wider ${currentTheme.accentText}`}>
              Simple 3-Step Process
            </span>
            <h2 className="text-3xl font-black text-slate-900">
              How TutorConnect Works
            </h2>
            <p className="text-sm text-slate-600">
              Whether you are looking for academic guidance or wanting to share your teaching expertise.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* For Students */}
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-lg">For Students & Parents</h3>
                    <p className="text-xs text-slate-500">Find the right tutor in minutes</p>
                  </div>
                </div>

                {/* Animated Student Avatar Preview */}
                <div className="flex items-center gap-2 bg-indigo-50/80 px-3 py-1.5 rounded-2xl border border-indigo-100">
                  <AnimatedStudentAvatar
                    src={DEFAULT_ANIMATED_STUDENT_AVATAR}
                    size="sm"
                    name="Student"
                    showAnimationRings={false}
                  />
                  <div className="text-left hidden sm:block">
                    <span className="text-[10px] font-bold text-indigo-700 block">Animated Avatar</span>
                    <span className="text-[9px] text-slate-500">Aarav (Scholar)</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Search & Filter Tutors</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Search by your subject, class, city, hourly budget, and online or in-person mode.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Send Tuition Request</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Specify your learning goals, target exam dates, and preferred timing slots with 1 click.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Teacher Accepts & Starts Classes</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Once accepted, direct contact details are shared. Begin 1-on-1 personalized lessons!
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={() => onOpenAuth('login', 'student')}
                  className="py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Student Login</span>
                </button>
                <button
                  onClick={() => onOpenAuth('register', 'student')}
                  className="py-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-colors"
                >
                  Sign Up as Student
                </button>
              </div>
            </div>

            {/* For Teachers */}
            <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
              <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-lg">For Teachers & Tutors</h3>
                  <p className="text-xs text-slate-500">Grow your tuition students & earnings</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Create Comprehensive Profile</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Add your degrees, qualifications, years of experience, hourly fee, and available slots.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Get Verified by Admin</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Our admin team reviews submitted credentials and awards the official <strong>Verified Badge</strong>.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Receive & Accept Inquiries</h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Get student tuition requests directly in your dashboard with zero commission cuts.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={() => onOpenAuth('login', 'teacher')}
                  className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Teacher Login</span>
                </button>
                <button
                  onClick={() => onOpenAuth('register', 'teacher')}
                  className="py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-bold transition-colors"
                >
                  Join as Teacher
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust & Safety Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`${currentTheme.safetyBannerBg} rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl border border-white/10`}>
          <div className="relative z-10 max-w-3xl space-y-4">
            <span className={`text-xs font-bold uppercase tracking-wider ${currentTheme.badgeText}`}>
              Safety & Verification First
            </span>
            <h2 className="text-3xl font-black">
              Why Parents & Students Rely on TutorConnect
            </h2>
            <p className="text-sm text-slate-200 leading-relaxed">
              We know academic mentorship requires trust. That's why every teacher profile passes through an administrative verification queue before displaying verified badges.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6">
              <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2 backdrop-blur-xs">
                <FileCheck2 className="w-6 h-6 text-emerald-400" />
                <h4 className="font-bold text-sm">Verified Credentials</h4>
                <p className="text-xs text-slate-300">Degrees, certificates, and ID records reviewed by system admin.</p>
              </div>

              <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2 backdrop-blur-xs">
                <Users className="w-6 h-6 text-sky-400" />
                <h4 className="font-bold text-sm">Direct Collaboration</h4>
                <p className="text-xs text-slate-300">Direct communication between student and teacher without broker calls.</p>
              </div>

              <div className="p-4 rounded-2xl bg-white/10 border border-white/15 space-y-2 backdrop-blur-xs">
                <ShieldCheck className="w-6 h-6 text-amber-400" />
                <h4 className="font-bold text-sm">Transparent Pricing</h4>
                <p className="text-xs text-slate-300">Clear hourly and monthly rates with no hidden agency commission.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 24x7 Academic Helpline & Counselor Assistance Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl p-8 sm:p-10 bg-gradient-to-br from-amber-500/10 via-rose-500/10 to-indigo-500/10 border-2 border-amber-300/80 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-3 text-center lg:text-left max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 border border-amber-300 text-amber-900 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>24x7 Academic Support & Counseling Desk</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-950">
              Need Help Finding the Right Tutor? Speak with Our Academic Counselors
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              Call our All-India Toll-Free Helpline at <strong className="text-slate-900 font-mono">1800-889-2026</strong> for free teacher recommendations, syllabus planning (CBSE, ICSE, IIT-JEE, NEET), or educator verification assistance.
            </p>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2 text-xs font-semibold text-slate-700">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                100% Free Calling
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Zero Brokerage
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Instant 15-Min Callback
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-3 w-full sm:w-auto shrink-0">
            <a
              href="tel:18008892026"
              className="px-6 py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-amber-500/25 transition-all hover:scale-102"
            >
              <PhoneCall className="w-4 h-4 fill-slate-950 animate-bounce-subtle" />
              <span>Call Toll-Free: 1800-889-2026</span>
            </a>

            <button
              onClick={onOpenHelpline}
              className="px-6 py-3.5 rounded-2xl bg-white hover:bg-slate-50 border-2 border-slate-300 text-slate-900 font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all hover:scale-102 cursor-pointer"
            >
              <Headphones className="w-4 h-4 text-indigo-600" />
              <span>Request Callback / WhatsApp</span>
            </button>
          </div>
        </div>
      </section>

      {/* XAMPP Notice Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-6 rounded-3xl bg-gradient-to-r from-sky-50 via-indigo-50 to-purple-50 border border-sky-200 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="space-y-1 text-center sm:text-left">
            <h3 className="text-lg font-black text-slate-900">
              Looking for the PHP backend code & MySQL database for XAMPP?
            </h3>
            <p className="text-xs text-slate-600 max-w-2xl">
              TutorConnect includes complete PHP scripts (<code className="font-mono text-indigo-700">auth</code>, <code className="font-mono text-indigo-700">student</code>, <code className="font-mono text-indigo-700">teacher</code>, <code className="font-mono text-indigo-700">admin</code>), PDO MySQL connection, and <code className="font-mono text-indigo-700">tutorconnect.sql</code>.
            </p>
          </div>

          <button
            onClick={onOpenXamppModal}
            className="px-5 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-2 shadow-md shrink-0 transition-all hover:scale-102"
          >
            <span>View PHP & SQL Source Files</span>
            <ArrowRight className="w-4 h-4 text-sky-400" />
          </button>
        </div>
      </section>
    </div>
  );
};
