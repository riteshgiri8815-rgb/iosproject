import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { TeacherProfile, User, VerificationStatus } from '../types';
import {
  Shield,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Users,
  AlertTriangle,
  Search,
  FileCheck2,
  Ban,
  Unlock,
  GraduationCap,
  Briefcase,
  DollarSign,
  Layers,
  Sparkles,
  ExternalLink,
  MessageSquare
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    currentUser,
    allUsers,
    allTeachers,
    allStudents,
    allRequests,
    verifyTeacher,
    toggleBlockUser
  } = useAuth();

  const [adminTab, setAdminTab] = useState<'verifications' | 'users' | 'requests'>('verifications');
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'student' | 'teacher'>('all');

  // Verification modal
  const [selectedTeacherForVerify, setSelectedTeacherForVerify] = useState<TeacherProfile | null>(null);
  const [verifyDecision, setVerifyDecision] = useState<'verified' | 'rejected'>('verified');
  const [verifyNotes, setVerifyNotes] = useState('All degrees and university credentials verified.');

  // Pending teachers
  const pendingTeachers = allTeachers.filter(t => t.verificationStatus === 'pending');
  const verifiedTeachers = allTeachers.filter(t => t.verificationStatus === 'verified');
  const totalStudents = allUsers.filter(u => u.role === 'student');
  const totalTeachers = allUsers.filter(u => u.role === 'teacher');
  const blockedUsers = allUsers.filter(u => u.isBlocked);

  // Filtered users list
  const filteredUsers = allUsers.filter(u => {
    if (u.role === 'admin') return false; // don't show admin in user table
    if (userRoleFilter !== 'all' && u.role !== userRoleFilter) return false;
    if (userSearchQuery) {
      const q = userSearchQuery.toLowerCase();
      return u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.phone.includes(q);
    }
    return true;
  });

  const handleOpenVerifyModal = (teacher: TeacherProfile, decision: 'verified' | 'rejected') => {
    setSelectedTeacherForVerify(teacher);
    setVerifyDecision(decision);
    setVerifyNotes(
      decision === 'verified'
        ? `Academic certificates and identity verified on ${new Date().toLocaleDateString()}. Verified Teacher badge awarded.`
        : 'Submitted documents were insufficient or could not be verified with university registers.'
    );
  };

  const handleConfirmVerification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTeacherForVerify) return;

    verifyTeacher(selectedTeacherForVerify.id, verifyDecision, verifyNotes.trim());
    setSelectedTeacherForVerify(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Admin Banner */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-center md:items-start justify-between gap-6 border border-slate-800">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-purple-900/40">
            <Shield className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black">TutorConnect Admin Control Center</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-400/30">
                Super Admin
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Logged in as <strong className="text-white">{currentUser?.email}</strong>. Manage teacher credentials, oversee student requests, and maintain platform integrity.
            </p>
          </div>
        </div>

        {/* System Health Stats */}
        <div className="flex items-center gap-3">
          <div className="text-center bg-white/5 border border-white/10 px-4 py-3 rounded-2xl">
            <span className="block text-2xl font-black text-amber-400">
              {pendingTeachers.length}
            </span>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
              Pending Review
            </span>
          </div>

          <div className="text-center bg-white/5 border border-white/10 px-4 py-3 rounded-2xl">
            <span className="block text-2xl font-black text-emerald-400">
              {verifiedTeachers.length}
            </span>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
              Verified Tutors
            </span>
          </div>

          <div className="text-center bg-white/5 border border-white/10 px-4 py-3 rounded-2xl">
            <span className="block text-2xl font-black text-sky-400">
              {allRequests.length}
            </span>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
              Tuition Requests
            </span>
          </div>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-6 text-sm font-bold overflow-x-auto">
        <button
          onClick={() => setAdminTab('verifications')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors shrink-0 ${
            adminTab === 'verifications'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          <span>Teacher Verification Queue</span>
          {pendingTeachers.length > 0 && (
            <span className="px-2 py-0.5 rounded-full text-xs font-extrabold bg-amber-500 text-white">
              {pendingTeachers.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setAdminTab('users')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors shrink-0 ${
            adminTab === 'users'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Manage Students & Teachers ({allUsers.length - 1})</span>
          {blockedUsers.length > 0 && (
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-rose-500 text-white">
              {blockedUsers.length} blocked
            </span>
          )}
        </button>

        <button
          onClick={() => setAdminTab('requests')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors shrink-0 ${
            adminTab === 'requests'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>All Platform Tuition Requests ({allRequests.length})</span>
        </button>
      </div>

      {/* Tab 1: Teacher Verification Queue */}
      {adminTab === 'verifications' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black text-slate-900">
                Pending Teacher Qualification Verifications
              </h2>
              <p className="text-xs text-slate-500">
                Review submitted educational qualifications, certificates, and experience before awarding the <strong>Verified Teacher badge</strong>.
              </p>
            </div>
          </div>

          {pendingTeachers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {pendingTeachers.map(teacher => (
                <div
                  key={teacher.id}
                  className="bg-white rounded-2xl border-2 border-amber-200 p-6 shadow-sm flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start gap-4">
                      <img
                        src={teacher.avatarUrl}
                        alt={teacher.name}
                        className="w-16 h-16 rounded-2xl object-cover border border-slate-200"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-extrabold text-slate-900 text-base truncate">
                            {teacher.name}
                          </h3>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            Pending Review
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">{teacher.email}</p>
                        <p className="text-xs text-indigo-700 font-semibold mt-1">
                          {teacher.qualification}
                        </p>
                      </div>
                    </div>

                    {/* Teacher Details Details */}
                    <div className="mt-4 p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs text-slate-700">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Experience:</span>
                        <span className="font-bold">{teacher.experience} Years</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Location:</span>
                        <span className="font-semibold">{teacher.location}, {teacher.city}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Subjects:</span>
                        <span className="font-bold text-indigo-700">{teacher.subjects.join(', ')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Classes:</span>
                        <span className="font-semibold">{teacher.classes.join(', ')}</span>
                      </div>
                      <div className="pt-2 border-t border-slate-200">
                        <span className="text-slate-500 font-medium">Uploaded Document:</span>
                        <div className="mt-1 flex items-center gap-1.5 font-mono text-[11px] bg-white p-1.5 rounded border border-slate-200 text-slate-800">
                          <FileCheck2 className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{teacher.degreesDocuments || 'Degree_Certificate_PoojaIyer.pdf'}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Approve / Reject Actions */}
                  <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                    <button
                      onClick={() => handleOpenVerifyModal(teacher, 'rejected')}
                      className="px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 transition-colors"
                    >
                      Reject Application
                    </button>
                    <button
                      onClick={() => handleOpenVerifyModal(teacher, 'verified')}
                      className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm shadow-emerald-200 flex items-center gap-1.5 transition-all"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Approve & Award Badge</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">Verification Queue is Clean!</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                All teacher applicants have been reviewed. New teacher registrations will automatically appear here.
              </p>
            </div>
          )}

          {/* Already Verified Teachers Section */}
          <div className="mt-10 pt-6 border-t border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <span>Currently Verified Teachers ({verifiedTeachers.length})</span>
            </h3>

            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
              <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
                <thead className="bg-slate-50 font-bold text-slate-600">
                  <tr>
                    <th className="px-4 py-3">Teacher</th>
                    <th className="px-4 py-3">Qualification</th>
                    <th className="px-4 py-3">Subjects</th>
                    <th className="px-4 py-3">Rate</th>
                    <th className="px-4 py-3">Badge Status</th>
                    <th className="px-4 py-3">Admin Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {verifiedTeachers.map(teacher => (
                    <tr key={teacher.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-semibold text-slate-900 flex items-center gap-2">
                        <img
                          src={teacher.avatarUrl}
                          alt={teacher.name}
                          className="w-7 h-7 rounded-full object-cover"
                        />
                        <span>{teacher.name}</span>
                      </td>
                      <td className="px-4 py-3 text-slate-600">{teacher.qualification}</td>
                      <td className="px-4 py-3 text-slate-600">{teacher.subjects.slice(0, 2).join(', ')}</td>
                      <td className="px-4 py-3 font-bold text-slate-900">₹{teacher.hourlyFee}/hr</td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Verified
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-500 max-w-xs truncate">
                        {teacher.verificationNotes}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Manage All Users (Students & Teachers) */}
      {adminTab === 'users' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-black text-slate-900">
                User Management & Access Control
              </h2>
              <p className="text-xs text-slate-500">
                Search, audit, and block or unblock student and teacher accounts.
              </p>
            </div>

            {/* Role Filter & Search */}
            <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={userSearchQuery}
                  onChange={e => setUserSearchQuery(e.target.value)}
                  placeholder="Search user name or email..."
                  className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-slate-300 text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <select
                value={userRoleFilter}
                onChange={e => setUserRoleFilter(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-semibold bg-white cursor-pointer"
              >
                <option value="all">All Roles</option>
                <option value="student">Students Only</option>
                <option value="teacher">Teachers Only</option>
              </select>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
              <thead className="bg-slate-50 font-bold text-slate-600">
                <tr>
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Contact</th>
                  <th className="px-4 py-3">Joined</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map(user => (
                  <tr key={user.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-3">
                        <img
                          src={
                            user.avatarUrl ||
                            'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80'
                          }
                          alt={user.name}
                          className="w-8 h-8 rounded-full object-cover border border-slate-200"
                        />
                        <div>
                          <p className="font-bold text-slate-900">{user.name}</p>
                          <p className="text-[11px] text-slate-500">{user.email}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3.5">
                      <span
                        className={`capitalize px-2 py-0.5 rounded text-[10px] font-bold ${
                          user.role === 'teacher'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        }`}
                      >
                        {user.role}
                      </span>
                    </td>

                    <td className="px-4 py-3.5 text-slate-600 font-mono text-[11px]">
                      {user.phone}
                    </td>

                    <td className="px-4 py-3.5 text-slate-500">
                      {user.createdAt}
                    </td>

                    <td className="px-4 py-3.5">
                      {user.isBlocked ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                          <Ban className="w-3 h-3 text-rose-600" />
                          Suspended / Blocked
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Active
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3.5 text-right">
                      {user.isBlocked ? (
                        <button
                          onClick={() => toggleBlockUser(user.id)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center gap-1 ml-auto border border-emerald-200 transition-colors"
                        >
                          <Unlock className="w-3.5 h-3.5" />
                          <span>Unblock</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => toggleBlockUser(user.id)}
                          className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center gap-1 ml-auto border border-rose-200 transition-colors"
                        >
                          <Ban className="w-3.5 h-3.5" />
                          <span>Block User</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: All Tuition Requests Oversight */}
      {adminTab === 'requests' && (
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-black text-slate-900">
              Platform Tuition Requests Audit
            </h2>
            <p className="text-xs text-slate-500">
              Live log of every tuition connection request sent by students to teachers.
            </p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="min-w-full divide-y divide-slate-200 text-left text-xs">
              <thead className="bg-slate-50 font-bold text-slate-600">
                <tr>
                  <th className="px-4 py-3">Student</th>
                  <th className="px-4 py-3">Teacher</th>
                  <th className="px-4 py-3">Subject & Mode</th>
                  <th className="px-4 py-3">Timings</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {allRequests.map(req => (
                  <tr key={req.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <p className="font-bold text-slate-900">{req.studentName}</p>
                      <p className="text-[11px] text-slate-500">{req.studentClass}</p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="font-semibold text-slate-900">{req.teacherName}</p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="font-bold text-indigo-700">{req.subject}</p>
                      <span className="capitalize text-[10px] text-slate-500">{req.teachingMode}</span>
                    </td>

                    <td className="px-4 py-3 text-slate-600">
                      {req.preferredTimings}
                    </td>

                    <td className="px-4 py-3">
                      {req.status === 'accepted' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Accepted
                        </span>
                      )}
                      {req.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                          Pending
                        </span>
                      )}
                      {req.status === 'rejected' && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                          Rejected
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-slate-400 font-mono text-[11px]">
                      {req.createdAt}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Verification Confirmation Modal */}
      {selectedTeacherForVerify && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div
              className={`p-5 text-white ${
                verifyDecision === 'verified' ? 'bg-emerald-700' : 'bg-rose-700'
              }`}
            >
              <h3 className="text-base font-bold">
                {verifyDecision === 'verified' ? 'Approve Teacher & Award Badge' : 'Reject Teacher Verification'}
              </h3>
              <p className="text-xs opacity-90 mt-0.5">
                Teacher: <strong>{selectedTeacherForVerify.name}</strong>
              </p>
            </div>

            <form onSubmit={handleConfirmVerification} className="p-6 space-y-4">
              <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1">
                <p><strong>Qualification:</strong> {selectedTeacherForVerify.qualification}</p>
                <p><strong>Submitted Document:</strong> {selectedTeacherForVerify.degreesDocuments || 'Degree Certificate'}</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Verification Audit Notes:
                </label>
                <textarea
                  rows={3}
                  required
                  value={verifyNotes}
                  onChange={e => setVerifyNotes(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedTeacherForVerify(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-bold text-white shadow-sm transition-all ${
                    verifyDecision === 'verified'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  Confirm {verifyDecision === 'verified' ? 'Approval' : 'Rejection'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
