import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { TeacherProfile, RequestStatus, TeachingMode } from '../types';
import { INDIAN_TEACHER_PHOTOS } from '../data/mockData';
import {
  ShieldCheck,
  Clock,
  XCircle,
  CheckCircle2,
  Users,
  Star,
  GraduationCap,
  Briefcase,
  MapPin,
  Calendar,
  Save,
  Check,
  MessageSquare,
  FileCheck2,
  Edit,
  Mail,
  Phone,
  Image,
  Sparkles
} from 'lucide-react';

export const TeacherDashboard: React.FC = () => {
  const {
    currentUser,
    currentTeacherProfile,
    allRequests,
    respondToTuitionRequest,
    updateTeacherProfile
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'requests' | 'edit_profile'>('requests');
  const [requestFilter, setRequestFilter] = useState<'all' | RequestStatus>('all');

  // Response modal state for accepting/rejecting
  const [respondingReq, setRespondingReq] = useState<{
    id: string;
    action: RequestStatus;
    studentName: string;
  } | null>(null);
  const [replyMessage, setReplyMessage] = useState('');

  // Profile edit fields
  const [name, setName] = useState(currentTeacherProfile?.name || '');
  const [qualification, setQualification] = useState(currentTeacherProfile?.qualification || '');
  const [experience, setExperience] = useState(String(currentTeacherProfile?.experience || 4));
  const [hourlyFee, setHourlyFee] = useState(String(currentTeacherProfile?.hourlyFee || 600));
  const [monthlyFee, setMonthlyFee] = useState(String(currentTeacherProfile?.monthlyFee || 4800));
  const [subjects, setSubjects] = useState(currentTeacherProfile?.subjects.join(', ') || '');
  const [classes, setClasses] = useState(currentTeacherProfile?.classes.join(', ') || '');
  const [location, setLocation] = useState(currentTeacherProfile?.location || '');
  const [city, setCity] = useState(currentTeacherProfile?.city || '');
  const [teachingMode, setTeachingMode] = useState<TeachingMode>(currentTeacherProfile?.teachingMode || 'both');
  const [timings, setTimings] = useState(currentTeacherProfile?.availableTimings.join(', ') || '');
  const [about, setAbout] = useState(currentTeacherProfile?.about || '');
  const [avatarUrl, setAvatarUrl] = useState(currentTeacherProfile?.avatarUrl || '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!currentTeacherProfile) {
    return (
      <div className="max-w-4xl mx-auto py-16 px-4 text-center">
        <h2 className="text-xl font-bold text-slate-800">No Teacher Profile Found</h2>
        <p className="text-xs text-slate-500 mt-2">
          Please log in with a teacher account or complete teacher registration.
        </p>
      </div>
    );
  }

  // Teacher incoming requests
  const teacherRequests = allRequests.filter(
    r =>
      r.teacherId === currentTeacherProfile.id ||
      r.teacherName.toLowerCase() === currentTeacherProfile.name.toLowerCase()
  );

  const filteredRequests = teacherRequests.filter(r => {
    if (requestFilter === 'all') return true;
    return r.status === requestFilter;
  });

  const handleOpenResponse = (reqId: string, action: RequestStatus, studentName: string) => {
    setRespondingReq({ id: reqId, action, studentName });
    if (action === 'accepted') {
      setReplyMessage('Hi! I have accepted your request. Let us connect to discuss your syllabus and weekly schedule.');
    } else {
      setReplyMessage('Thank you for reaching out. Unfortunately, my current tuition batch is full at this time.');
    }
  };

  const handleConfirmResponse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!respondingReq) return;

    respondToTuitionRequest(respondingReq.id, respondingReq.action, replyMessage.trim());
    setRespondingReq(null);
    setReplyMessage('');
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateTeacherProfile({
      name,
      qualification,
      experience: Number(experience) || 1,
      hourlyFee: Number(hourlyFee) || 500,
      monthlyFee: Number(monthlyFee) || (Number(hourlyFee) * 8),
      subjects: subjects.split(',').map(s => s.trim()).filter(Boolean),
      classes: classes.split(',').map(c => c.trim()).filter(Boolean),
      location,
      city,
      teachingMode,
      availableTimings: timings.split(',').map(t => t.trim()).filter(Boolean),
      about,
      avatarUrl: avatarUrl || currentTeacherProfile.avatarUrl
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const isVerified = currentTeacherProfile.verificationStatus === 'verified';
  const isPending = currentTeacherProfile.verificationStatus === 'pending';
  const isRejected = currentTeacherProfile.verificationStatus === 'rejected';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Verification Status Banner */}
      {isVerified && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-black text-emerald-900 flex items-center gap-1.5">
                <span>Verified Teacher Badge Active</span>
                <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-emerald-200 text-emerald-800">
                  Certified by Admin
                </span>
              </p>
              <p className="text-xs text-emerald-700 mt-0.5">
                Your profile displays the official verified badge to students, granting 4x higher tuition inquiries.
              </p>
            </div>
          </div>
        </div>
      )}

      {isPending && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm">
              <Clock className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <p className="text-sm font-black text-amber-900">
                Profile Verification Under Admin Review
              </p>
              <p className="text-xs text-amber-700 mt-0.5">
                Our administrative team is verifying your academic degrees and credentials. You can still receive student requests in the meantime.
              </p>
            </div>
          </div>
        </div>
      )}

      {isRejected && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <XCircle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-black text-rose-900">
                Verification Rejected by Admin
              </p>
              <p className="text-xs text-rose-700 mt-0.5">
                Note: {currentTeacherProfile.verificationNotes || 'Please upload valid degree certificates.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Teacher Profile Summary Card */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
          <div className="relative">
            <img
              src={currentTeacherProfile.avatarUrl}
              alt={currentTeacherProfile.name}
              className="w-20 h-20 rounded-2xl object-cover ring-4 ring-white/20 shadow-md"
            />
            {isVerified && (
              <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-white p-1 rounded-full ring-2 ring-slate-900">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
              <h1 className="text-2xl font-black">{currentTeacherProfile.name}</h1>
              {isVerified ? (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  Verified Teacher
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30">
                  Pending Verification
                </span>
              )}
            </div>

            <p className="text-xs text-indigo-200 mt-1 flex items-center justify-center sm:justify-start gap-2">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>{currentTeacherProfile.qualification}</span>
              <span>•</span>
              <Briefcase className="w-3.5 h-3.5" />
              <span>{currentTeacherProfile.experience} Years Exp</span>
            </p>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 mt-3 text-xs text-slate-300">
              <span>Hourly Rate: <strong className="text-white">₹{currentTeacherProfile.hourlyFee}</strong></span>
              <span>Monthly Approx: <strong className="text-white">₹{currentTeacherProfile.monthlyFee}</strong></span>
              <span className="flex items-center gap-1 text-amber-400 font-bold">
                <Star className="w-3.5 h-3.5 fill-amber-400" />
                {currentTeacherProfile.rating.toFixed(1)} ({currentTeacherProfile.reviewCount} reviews)
              </span>
            </div>
          </div>
        </div>

        {/* Quick Metric Pills */}
        <div className="flex items-center gap-3">
          <div className="text-center bg-white/10 px-4 py-3 rounded-2xl border border-white/10">
            <span className="block text-2xl font-black">{teacherRequests.length}</span>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
              Total Requests
            </span>
          </div>
          <div className="text-center bg-emerald-500/20 px-4 py-3 rounded-2xl border border-emerald-500/30">
            <span className="block text-2xl font-black text-emerald-300">
              {teacherRequests.filter(r => r.status === 'accepted').length}
            </span>
            <span className="text-[10px] text-emerald-300 uppercase font-bold tracking-wider">
              Active Tuitions
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-6 text-sm font-bold">
        <button
          onClick={() => setActiveTab('requests')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'requests'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Student Inquiries & Requests ({teacherRequests.length})</span>
          {teacherRequests.filter(r => r.status === 'pending').length > 0 && (
            <span className="px-2 py-0.5 rounded-full text-xs bg-rose-500 text-white font-bold">
              {teacherRequests.filter(r => r.status === 'pending').length} new
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('edit_profile')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'edit_profile'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Edit className="w-4 h-4" />
          <span>Edit Teacher Profile & Rates</span>
        </button>
      </div>

      {/* Tab 1: Student Requests */}
      {activeTab === 'requests' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 mr-2">Filter Requests:</span>
            {[
              { id: 'all', label: `All (${teacherRequests.length})` },
              {
                id: 'pending',
                label: `Pending Action (${teacherRequests.filter(r => r.status === 'pending').length})`
              },
              {
                id: 'accepted',
                label: `Accepted (${teacherRequests.filter(r => r.status === 'accepted').length})`
              },
              {
                id: 'rejected',
                label: `Rejected (${teacherRequests.filter(r => r.status === 'rejected').length})`
              }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setRequestFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  requestFilter === tab.id
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {filteredRequests.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredRequests.map(req => {
                const isPending = req.status === 'pending';
                const isAccepted = req.status === 'accepted';
                const isRejected = req.status === 'rejected';

                return (
                  <div
                    key={req.id}
                    className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between"
                  >
                    <div>
                      {/* Top Student Header */}
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-extrabold text-slate-900 text-base">{req.studentName}</h3>
                            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                              {req.studentClass}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-400" />
                            {req.studentLocation}
                          </p>
                        </div>

                        {/* Status badge */}
                        <div>
                          {isPending && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                              <Clock className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                              Action Needed
                            </span>
                          )}
                          {isAccepted && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                              Accepted
                            </span>
                          )}
                          {isRejected && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                              <XCircle className="w-3.5 h-3.5 text-rose-500" />
                              Rejected
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Request Specs */}
                      <div className="mt-4 p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-2 text-xs text-slate-700">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <span className="text-slate-400 block text-[11px]">Subject:</span>
                            <span className="font-bold text-indigo-700">{req.subject}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[11px]">Tuition Mode:</span>
                            <span className="font-bold capitalize">{req.teachingMode}</span>
                          </div>
                        </div>

                        <div>
                          <span className="text-slate-400 block text-[11px]">Preferred Timing:</span>
                          <span className="font-semibold text-slate-800">{req.preferredTimings}</span>
                        </div>

                        <div className="pt-2 border-t border-slate-200/60">
                          <span className="text-slate-400 block text-[11px]">Student Requirement Message:</span>
                          <p className="mt-0.5 text-slate-800 italic leading-relaxed">
                            "{req.studentMessage}"
                          </p>
                        </div>
                      </div>

                      {/* If Teacher Already Replied */}
                      {req.teacherResponseNote && (
                        <div
                          className={`mt-3 p-3 rounded-xl text-xs ${
                            isAccepted
                              ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                              : 'bg-rose-50 border border-rose-200 text-rose-900'
                          }`}
                        >
                          <p className="font-bold">Your Response Note:</p>
                          <p className="mt-0.5">{req.teacherResponseNote}</p>
                        </div>
                      )}
                    </div>

                    {/* Actions or Student Contact */}
                    <div className="mt-5 pt-3 border-t border-slate-100">
                      {isPending ? (
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenResponse(req.id, 'rejected', req.studentName)}
                            className="px-3.5 py-2 rounded-xl text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-colors"
                          >
                            Decline Request
                          </button>
                          <button
                            onClick={() => handleOpenResponse(req.id, 'accepted', req.studentName)}
                            className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm shadow-emerald-200 transition-all flex items-center gap-1.5"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Accept Request</span>
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                          <span className="text-slate-500 font-medium">Student Contact:</span>
                          <div className="flex items-center gap-3">
                            <span className="font-bold text-indigo-700 flex items-center gap-1">
                              <Phone className="w-3.5 h-3.5 text-indigo-500" />
                              {req.studentPhone}
                            </span>
                            <span className="text-slate-600 flex items-center gap-1">
                              <Mail className="w-3.5 h-3.5 text-slate-400" />
                              {req.studentEmail}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <Users className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No requests in this view</h3>
              <p className="text-xs text-slate-500">
                When students discover your profile and request tuition, their inquiries will appear here.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Edit Profile */}
      {activeTab === 'edit_profile' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 max-w-3xl shadow-xs">
          <div className="mb-6">
            <h3 className="text-lg font-bold text-slate-900">Edit Teacher Profile & Pricing</h3>
            <p className="text-xs text-slate-500">
              Provide thorough details about your teaching experience, degrees, and availability so students can find you easily.
            </p>
          </div>

          {saveSuccess && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Teacher profile updated successfully!</span>
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4">
            {/* Indian Teacher Photo Presets */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Choose Profile Photo (Indian Educator Portraits)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {INDIAN_TEACHER_PHOTOS.map((preset, idx) => (
                  <button
                    type="button"
                    key={idx}
                    onClick={() => setAvatarUrl(preset.url)}
                    className={`flex items-center gap-2.5 p-2 rounded-2xl border transition-all text-xs text-left ${
                      avatarUrl === preset.url
                        ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-500/20 text-indigo-950 font-bold shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                    }`}
                  >
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-9 h-9 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <span className="truncate text-[11px]">{preset.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Profile Photo URL
                </label>
                <input
                  type="url"
                  value={avatarUrl}
                  onChange={e => setAvatarUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Highest Qualification / Degree *
              </label>
              <input
                type="text"
                required
                value={qualification}
                onChange={e => setQualification(e.target.value)}
                placeholder="e.g. Ph.D. in Applied Mathematics, B.Ed, M.Sc"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Teaching Experience (Years) *
                </label>
                <input
                  type="number"
                  min="0"
                  max="45"
                  required
                  value={experience}
                  onChange={e => setExperience(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Hourly Fee (₹) *
                </label>
                <input
                  type="number"
                  min="100"
                  step="50"
                  required
                  value={hourlyFee}
                  onChange={e => setHourlyFee(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Monthly Package (₹)
                </label>
                <input
                  type="number"
                  min="500"
                  step="100"
                  value={monthlyFee}
                  onChange={e => setMonthlyFee(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Subjects Taught (comma separated) *
              </label>
              <input
                type="text"
                required
                value={subjects}
                onChange={e => setSubjects(e.target.value)}
                placeholder="e.g. Mathematics, Physics, Calculus, Statistics"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Classes / Target Grades Handled (comma separated) *
              </label>
              <input
                type="text"
                required
                value={classes}
                onChange={e => setClasses(e.target.value)}
                placeholder="e.g. Class 10, Class 11, Class 12, IIT-JEE Prep"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Teaching Mode *
                </label>
                <select
                  value={teachingMode}
                  onChange={e => setTeachingMode(e.target.value as TeachingMode)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden bg-white"
                >
                  <option value="both">Both Online & Offline</option>
                  <option value="online">Online Only</option>
                  <option value="offline">Home / Offline Only</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  City / Town *
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={e => setCity(e.target.value)}
                  placeholder="e.g. Delhi, Mumbai"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Area / Locality *
                </label>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="e.g. Connaught Place, Central Delhi"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Available Timings / Batches (comma separated)
              </label>
              <input
                type="text"
                value={timings}
                onChange={e => setTimings(e.target.value)}
                placeholder="e.g. Weekday Evenings (5 PM - 8 PM), Saturday Mornings"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                About You & Teaching Methodology *
              </label>
              <textarea
                rows={4}
                required
                value={about}
                onChange={e => setAbout(e.target.value)}
                placeholder="Describe your teaching philosophy, achievements, test series method, etc."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-indigo-200 transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Save Profile Changes</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Response Dialog Modal */}
      {respondingReq && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div
              className={`p-5 text-white ${
                respondingReq.action === 'accepted' ? 'bg-emerald-700' : 'bg-rose-700'
              }`}
            >
              <h3 className="text-base font-bold">
                {respondingReq.action === 'accepted' ? 'Accept Tuition Request' : 'Decline Tuition Request'}
              </h3>
              <p className="text-xs opacity-90 mt-0.5">
                For student: <strong>{respondingReq.studentName}</strong>
              </p>
            </div>

            <form onSubmit={handleConfirmResponse} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Message / Reply to Student:
                </label>
                <textarea
                  rows={3}
                  required
                  value={replyMessage}
                  onChange={e => setReplyMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRespondingReq(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-xs font-bold text-white shadow-sm transition-all ${
                    respondingReq.action === 'accepted'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  Confirm {respondingReq.action === 'accepted' ? 'Acceptance' : 'Rejection'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
