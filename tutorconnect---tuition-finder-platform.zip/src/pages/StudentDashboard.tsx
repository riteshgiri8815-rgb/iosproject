import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { RequestStatus, TeachingMode } from '../types';
import {
  AnimatedStudentAvatar,
  ANIMATED_STUDENT_AVATARS,
  DEFAULT_ANIMATED_STUDENT_AVATAR
} from '../components/AnimatedStudentAvatar';
import {
  GraduationCap,
  Clock,
  CheckCircle2,
  XCircle,
  MapPin,
  BookOpen,
  Phone,
  Mail,
  User,
  Edit3,
  Calendar,
  Search,
  MessageSquare,
  ShieldCheck,
  Save,
  Check,
  Sparkles,
  Smile
} from 'lucide-react';

interface StudentDashboardProps {
  onFindTutors: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onFindTutors }) => {
  const {
    currentUser,
    currentStudentProfile,
    allRequests,
    allTeachers,
    updateStudentProfile
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'requests' | 'profile'>('requests');
  const [requestFilter, setRequestFilter] = useState<'all' | RequestStatus>('all');
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);

  // Edit profile state
  const [gradeClass, setGradeClass] = useState(currentStudentProfile?.gradeClass || 'Class 10 CBSE');
  const [targetSubjects, setTargetSubjects] = useState(
    currentStudentProfile?.targetSubjects?.join(', ') || 'Mathematics, Science'
  );
  const [location, setLocation] = useState(currentStudentProfile?.location || 'Sector 62, Noida');
  const [city, setCity] = useState(currentStudentProfile?.city || 'Delhi');
  const [selectedAvatar, setSelectedAvatar] = useState(
    currentUser?.avatarUrl || DEFAULT_ANIMATED_STUDENT_AVATAR
  );

  // Filter requests belonging to this student
  const studentRequests = allRequests.filter(
    r =>
      r.studentEmail === currentUser?.email ||
      r.studentId === currentUser?.id ||
      r.studentId === currentStudentProfile?.id
  );

  const filteredRequests = studentRequests.filter(r => {
    if (requestFilter === 'all') return true;
    return r.status === requestFilter;
  });

  const handleSelectAnimatedAvatar = (url: string) => {
    setSelectedAvatar(url);
    updateStudentProfile({
      avatarUrl: url
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateStudentProfile({
      gradeClass,
      targetSubjects: targetSubjects.split(',').map(s => s.trim()).filter(Boolean),
      location,
      city,
      avatarUrl: selectedAvatar
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Student Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-center md:items-start justify-between gap-6 relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left z-10">
          <div className="relative group">
            <AnimatedStudentAvatar
              src={currentUser?.avatarUrl || DEFAULT_ANIMATED_STUDENT_AVATAR}
              name={currentUser?.name}
              size="xl"
              showFloatingIcons={true}
            />
            <button
              onClick={() => setShowAvatarPicker(!showAvatarPicker)}
              className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-slate-900/90 text-[10px] font-bold text-sky-300 border border-sky-400/40 hover:bg-slate-800 transition-all flex items-center gap-1 shadow-md whitespace-nowrap"
            >
              <Sparkles className="w-2.5 h-2.5 text-amber-400" />
              <span>Change Avatar</span>
            </button>
          </div>

          <div>
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <h1 className="text-2xl font-black">{currentUser?.name}</h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                Active Student
              </span>
            </div>
            <p className="text-xs text-indigo-200 mt-1 flex items-center justify-center sm:justify-start gap-2">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>{currentStudentProfile?.gradeClass || 'Student'}</span>
              <span>•</span>
              <MapPin className="w-3.5 h-3.5" />
              <span>{currentStudentProfile?.city || 'Local'}</span>
            </p>
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 mt-3">
              {currentStudentProfile?.targetSubjects?.map((sub, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-white/10 text-white"
                >
                  {sub}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 z-10">
          <button
            onClick={() => setShowAvatarPicker(!showAvatarPicker)}
            className="px-3.5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center gap-1.5 border border-white/15 transition-all"
          >
            <Smile className="w-4 h-4 text-amber-400" />
            <span>Animated Avatars</span>
          </button>

          <button
            onClick={onFindTutors}
            className="px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all hover:scale-102 shrink-0"
          >
            <Search className="w-4 h-4" />
            <span>Search New Tutors</span>
          </button>
        </div>
      </div>

      {/* Animated Avatars Picker Drawer */}
      {showAvatarPicker && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white animate-in fade-in duration-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-sm flex items-center gap-2 text-white">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Select Your Animated Student Avatar</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Choose an animated character to personalize your profile picture across TutorConnect.
              </p>
            </div>
            <button
              onClick={() => setShowAvatarPicker(false)}
              className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800"
            >
              Done
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            {ANIMATED_STUDENT_AVATARS.map(avatar => {
              const isSelected = (currentUser?.avatarUrl || DEFAULT_ANIMATED_STUDENT_AVATAR) === avatar.url;
              return (
                <button
                  key={avatar.id}
                  onClick={() => handleSelectAnimatedAvatar(avatar.url)}
                  className={`p-3 rounded-2xl border transition-all text-center flex flex-col items-center gap-2 group ${
                    isSelected
                      ? 'bg-indigo-600/30 border-sky-400 ring-2 ring-sky-400/50'
                      : 'bg-slate-800/80 border-slate-700 hover:border-slate-500'
                  }`}
                >
                  <AnimatedStudentAvatar
                    src={avatar.url}
                    name={avatar.name}
                    size="md"
                    showAnimationRings={isSelected}
                  />
                  <div>
                    <p className="text-xs font-bold text-white truncate max-w-[100px]">{avatar.name}</p>
                    <p className="text-[10px] text-sky-300 font-semibold">{avatar.badge}</p>
                  </div>
                  {isSelected && (
                    <span className="text-[10px] font-bold text-emerald-400 flex items-center gap-0.5">
                      <Check className="w-3 h-3" /> Active
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-6 text-sm font-bold">
        <button
          onClick={() => setActiveTab('requests')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'requests'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>My Tuition Requests ({studentRequests.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors ${
            activeTab === 'profile'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Edit3 className="w-4 h-4" />
          <span>Edit My Learning Profile</span>
        </button>
      </div>

      {/* Tab 1: Tuition Requests */}
      {activeTab === 'requests' && (
        <div className="space-y-6">
          {/* Status filters */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 mr-2">Filter by Status:</span>
            {[
              { id: 'all', label: `All (${studentRequests.length})` },
              {
                id: 'pending',
                label: `Pending (${studentRequests.filter(r => r.status === 'pending').length})`
              },
              {
                id: 'accepted',
                label: `Accepted (${studentRequests.filter(r => r.status === 'accepted').length})`
              },
              {
                id: 'rejected',
                label: `Rejected (${studentRequests.filter(r => r.status === 'rejected').length})`
              }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setRequestFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                  requestFilter === tab.id
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {filteredRequests.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredRequests.map(req => {
                const teacherObj = allTeachers.find(t => t.id === req.teacherId);
                const isAccepted = req.status === 'accepted';
                const isPending = req.status === 'pending';
                const isRejected = req.status === 'rejected';

                return (
                  <div
                    key={req.id}
                    className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
                  >
                    <div>
                      {/* Teacher Header */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={req.teacherAvatar}
                            alt={req.teacherName}
                            className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                          />
                          <div>
                            <h3 className="font-bold text-slate-900 text-sm">{req.teacherName}</h3>
                            <p className="text-xs text-indigo-600 font-semibold">{req.subject}</p>
                          </div>
                        </div>

                        {/* Status Badge */}
                        <div>
                          {isPending && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                              <Clock className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                              Pending
                            </span>
                          )}
                          {isAccepted && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                              Accepted
                            </span>
                          )}
                          {isRejected && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                              <XCircle className="w-3.5 h-3.5 text-rose-500" />
                              Rejected
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Request Details */}
                      <div className="mt-4 p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5 text-xs text-slate-600">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-medium">Mode:</span>
                          <span className="font-bold text-slate-800 capitalize">{req.teachingMode}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-medium">Timings Requested:</span>
                          <span className="font-semibold text-slate-800">{req.preferredTimings}</span>
                        </div>
                        <div className="pt-1 border-t border-slate-200/60">
                          <p className="text-slate-400 text-[11px]">Your Note:</p>
                          <p className="text-slate-700 italic mt-0.5 line-clamp-2">"{req.studentMessage}"</p>
                        </div>
                      </div>

                      {/* Teacher Response Note */}
                      {req.teacherResponseNote && (
                        <div
                          className={`mt-3 p-3 rounded-xl text-xs ${
                            isAccepted
                              ? 'bg-emerald-50/80 border border-emerald-200 text-emerald-900'
                              : 'bg-rose-50/80 border border-rose-200 text-rose-900'
                          }`}
                        >
                          <p className="font-bold flex items-center gap-1">
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Teacher's Reply:</span>
                          </p>
                          <p className="mt-1 leading-relaxed">{req.teacherResponseNote}</p>
                        </div>
                      )}
                    </div>

                    {/* Unlocked Contact Details if Accepted */}
                    {isAccepted && teacherObj && (
                      <div className="mt-4 pt-3 border-t border-emerald-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <span className="text-emerald-700 font-bold flex items-center gap-1">
                          <Phone className="w-3.5 h-3.5 text-emerald-600" />
                          {teacherObj.phone}
                        </span>
                        <span className="text-slate-600 font-medium flex items-center gap-1">
                          <Mail className="w-3.5 h-3.5 text-slate-400" />
                          {teacherObj.email}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <Clock className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">No requests in this view</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Explore our directory of verified private tutors and send a tuition request for help with your studies.
              </p>
              <button
                onClick={onFindTutors}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold"
              >
                Browse Tutors Now
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Edit Profile */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 max-w-2xl shadow-xs">
          <div className="mb-6">
            <h3 className="text-lg font-bold text-slate-900">Student Profile Information</h3>
            <p className="text-xs text-slate-500">
              Keep your grade, target subjects, and location updated so teachers can review your requests accurately.
            </p>
          </div>

          {saveSuccess && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Profile details updated successfully!</span>
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4">
            {/* Animated Avatar Picker Field */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Choose Animated Avatar *
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
                {ANIMATED_STUDENT_AVATARS.map(avatar => {
                  const isSelected = selectedAvatar === avatar.url;
                  return (
                    <button
                      type="button"
                      key={avatar.id}
                      onClick={() => setSelectedAvatar(avatar.url)}
                      className={`p-2 rounded-2xl border transition-all text-center flex flex-col items-center gap-1.5 ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50 ring-2 ring-indigo-500/30'
                          : 'border-slate-200 hover:border-slate-300 bg-white'
                      }`}
                    >
                      <AnimatedStudentAvatar
                        src={avatar.url}
                        name={avatar.name}
                        size="md"
                        showAnimationRings={isSelected}
                      />
                      <span className="text-[10px] font-bold text-slate-700 truncate max-w-[70px]">
                        {avatar.name.split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Student Name
              </label>
              <input
                type="text"
                disabled
                value={currentUser?.name || ''}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-500 text-sm cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Registered Email
              </label>
              <input
                type="email"
                disabled
                value={currentUser?.email || ''}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-500 text-sm cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Class / Grade *
              </label>
              <input
                type="text"
                required
                value={gradeClass}
                onChange={e => setGradeClass(e.target.value)}
                placeholder="e.g. Class 10 CBSE, Class 12 ICSE"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Subjects You Need Help In (comma separated) *
              </label>
              <input
                type="text"
                required
                value={targetSubjects}
                onChange={e => setTargetSubjects(e.target.value)}
                placeholder="e.g. Mathematics, Physics, Chemistry"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  City *
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={e => setCity(e.target.value)}
                  placeholder="e.g. Delhi, Mumbai"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Locality / Address
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  placeholder="e.g. Sector 62, Noida"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-indigo-200 transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Save Profile Changes</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
