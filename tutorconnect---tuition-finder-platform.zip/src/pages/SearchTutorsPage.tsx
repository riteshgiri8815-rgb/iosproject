import React, { useState, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { TeacherProfile, SearchFilterState, TeachingMode } from '../types';
import { POPULAR_SUBJECTS, POPULAR_CLASSES, POPULAR_CITIES } from '../data/mockData';
import { TeacherCard } from '../components/TeacherCard';
import {
  Search,
  SlidersHorizontal,
  MapPin,
  BookOpen,
  GraduationCap,
  Wifi,
  Home,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  DollarSign
} from 'lucide-react';

interface SearchTutorsPageProps {
  initialFilters?: Partial<SearchFilterState>;
  onViewTeacherProfile: (teacher: TeacherProfile) => void;
  onRequestTuition: (teacher: TeacherProfile) => void;
}

export const SearchTutorsPage: React.FC<SearchTutorsPageProps> = ({
  initialFilters,
  onViewTeacherProfile,
  onRequestTuition
}) => {
  const { allTeachers } = useAuth();

  const [filters, setFilters] = useState<SearchFilterState>({
    searchQuery: initialFilters?.searchQuery || '',
    subject: initialFilters?.subject || '',
    classGrade: initialFilters?.classGrade || '',
    location: initialFilters?.location || '',
    teachingMode: initialFilters?.teachingMode || 'all',
    maxHourlyFee: initialFilters?.maxHourlyFee || 1500,
    verifiedOnly: initialFilters?.verifiedOnly || false,
    sortBy: initialFilters?.sortBy || 'recommended'
  });

  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Filter & Sort Logic
  const filteredTeachers = useMemo(() => {
    return allTeachers
      .filter(teacher => {
        // Exclude blocked teachers from search
        if (teacher.isBlocked) return false;

        // Search query (name, about, qualification, subjects)
        if (filters.searchQuery) {
          const q = filters.searchQuery.toLowerCase();
          const matchName = teacher.name.toLowerCase().includes(q);
          const matchAbout = teacher.about.toLowerCase().includes(q);
          const matchQual = teacher.qualification.toLowerCase().includes(q);
          const matchSubs = teacher.subjects.some(s => s.toLowerCase().includes(q));
          if (!matchName && !matchAbout && !matchQual && !matchSubs) return false;
        }

        // Subject filter
        if (filters.subject) {
          const subLower = filters.subject.toLowerCase();
          const hasSubject = teacher.subjects.some(s => s.toLowerCase().includes(subLower));
          if (!hasSubject) return false;
        }

        // Class / Grade filter
        if (filters.classGrade) {
          const gradeLower = filters.classGrade.toLowerCase();
          const hasGrade = teacher.classes.some(c => c.toLowerCase().includes(gradeLower));
          if (!hasGrade) return false;
        }

        // Location / City filter
        if (filters.location) {
          const locLower = filters.location.toLowerCase();
          const matchLoc =
            teacher.location.toLowerCase().includes(locLower) ||
            teacher.city.toLowerCase().includes(locLower);
          if (!matchLoc) return false;
        }

        // Teaching Mode filter
        if (filters.teachingMode !== 'all') {
          if (teacher.teachingMode !== 'both' && teacher.teachingMode !== filters.teachingMode) {
            return false;
          }
        }

        // Fee filter
        if (teacher.hourlyFee > filters.maxHourlyFee) {
          return false;
        }

        // Verified only filter
        if (filters.verifiedOnly && teacher.verificationStatus !== 'verified') {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (filters.sortBy === 'rating') {
          return b.rating - a.rating;
        }
        if (filters.sortBy === 'fee-asc') {
          return a.hourlyFee - b.hourlyFee;
        }
        if (filters.sortBy === 'fee-desc') {
          return b.hourlyFee - a.hourlyFee;
        }
        if (filters.sortBy === 'experience') {
          return b.experience - a.experience;
        }
        // Recommended default: Verified first, then rating
        const aVerified = a.verificationStatus === 'verified' ? 1 : 0;
        const bVerified = b.verificationStatus === 'verified' ? 1 : 0;
        if (bVerified !== aVerified) return bVerified - aVerified;
        return b.rating - a.rating;
      });
  }, [allTeachers, filters]);

  const handleResetFilters = () => {
    setFilters({
      searchQuery: '',
      subject: '',
      classGrade: '',
      location: '',
      teachingMode: 'all',
      maxHourlyFee: 1500,
      verifiedOnly: false,
      sortBy: 'recommended'
    });
  };

  const hasActiveFilters =
    filters.searchQuery ||
    filters.subject ||
    filters.classGrade ||
    filters.location ||
    filters.teachingMode !== 'all' ||
    filters.maxHourlyFee < 1500 ||
    filters.verifiedOnly;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Search Header Banner */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white">
        <div className="max-w-3xl space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
            Student Tuition Discovery Engine
          </span>
          <h1 className="text-2xl sm:text-3xl font-black">
            Find Your Ideal Private Tutor
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Filter by academic subject, target class, city, hourly fees, and verified credentials.
          </p>
        </div>

        {/* Global Search Input */}
        <div className="mt-6 relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={e => setFilters(prev => ({ ...prev, searchQuery: e.target.value }))}
            placeholder="Search by teacher name, subject (e.g. Calculus, Physics), qualification..."
            className="w-full pl-12 pr-4 py-3 rounded-2xl bg-slate-800 text-white placeholder-slate-400 border border-slate-700 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Main Grid: Filters Sidebar + Results */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        {/* Mobile filter toggle button */}
        <div className="lg:hidden flex items-center justify-between bg-white p-3 rounded-2xl border border-slate-200">
          <span className="text-xs font-bold text-slate-700">
            {filteredTeachers.length} Tutors Found
          </span>
          <button
            onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
            className="px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-700 text-xs font-bold flex items-center gap-1.5"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>
        </div>

        {/* Filters Sidebar */}
        <aside
          className={`lg:block bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6 ${
            mobileFilterOpen ? 'block' : 'hidden'
          }`}
        >
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
              <span>Filters</span>
            </h3>
            {hasActiveFilters && (
              <button
                onClick={handleResetFilters}
                className="text-xs font-semibold text-rose-600 hover:text-rose-800 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
          </div>

          {/* Verified Tutors Only Toggle */}
          <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-200/80">
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-emerald-900">Verified Badge Only</span>
              </div>
              <input
                type="checkbox"
                checked={filters.verifiedOnly}
                onChange={e => setFilters(prev => ({ ...prev, verifiedOnly: e.target.checked }))}
                className="w-4 h-4 text-emerald-600 rounded-sm focus:ring-emerald-500 cursor-pointer"
              />
            </label>
            <p className="text-[11px] text-emerald-700 mt-1">
              Shows only teachers whose degrees were verified by Admin.
            </p>
          </div>

          {/* Subject Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              Subject
            </label>
            <select
              value={filters.subject}
              onChange={e => setFilters(prev => ({ ...prev, subject: e.target.value }))}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden bg-slate-50"
            >
              <option value="">All Academic Subjects</option>
              {POPULAR_SUBJECTS.map((sub, idx) => (
                <option key={idx} value={sub}>
                  {sub}
                </option>
              ))}
            </select>
          </div>

          {/* Class / Grade Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              Class / Grade
            </label>
            <select
              value={filters.classGrade}
              onChange={e => setFilters(prev => ({ ...prev, classGrade: e.target.value }))}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden bg-slate-50"
            >
              <option value="">All Classes / Boards</option>
              {POPULAR_CLASSES.map((cls, idx) => (
                <option key={idx} value={cls}>
                  {cls}
                </option>
              ))}
            </select>
          </div>

          {/* City / Location Filter */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              City / Location
            </label>
            <select
              value={filters.location}
              onChange={e => setFilters(prev => ({ ...prev, location: e.target.value }))}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden bg-slate-50"
            >
              <option value="">All Locations</option>
              {POPULAR_CITIES.map((c, idx) => (
                <option key={idx} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Teaching Mode Toggle */}
          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
              Teaching Mode
            </label>
            <div className="grid grid-cols-2 gap-1.5 text-xs font-semibold">
              {[
                { id: 'all', label: 'All Modes' },
                { id: 'online', label: 'Online' },
                { id: 'offline', label: 'Home / Offline' },
                { id: 'both', label: 'Both' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() =>
                    setFilters(prev => ({ ...prev, teachingMode: item.id as any }))
                  }
                  className={`py-2 px-2 rounded-xl border transition-all text-center ${
                    filters.teachingMode === item.id
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Max Hourly Fee Slider */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Max Hourly Fee
              </label>
              <span className="text-xs font-extrabold text-indigo-600">
                ₹{filters.maxHourlyFee} / hr
              </span>
            </div>
            <input
              type="range"
              min="300"
              max="2000"
              step="50"
              value={filters.maxHourlyFee}
              onChange={e => setFilters(prev => ({ ...prev, maxHourlyFee: Number(e.target.value) }))}
              className="w-full accent-indigo-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1 font-mono">
              <span>₹300</span>
              <span>₹1000</span>
              <span>₹2000</span>
            </div>
          </div>
        </aside>

        {/* Results Column */}
        <main className="lg:col-span-3 space-y-5">
          {/* Top Sort Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-4 shadow-xs">
            <div className="text-xs text-slate-600">
              Showing <span className="font-extrabold text-slate-900">{filteredTeachers.length}</span>{' '}
              teachers matching criteria
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Sort by:</span>
              <select
                value={filters.sortBy}
                onChange={e => setFilters(prev => ({ ...prev, sortBy: e.target.value as any }))}
                className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-800 bg-slate-50 focus:outline-hidden cursor-pointer"
              >
                <option value="recommended">Recommended (Verified First)</option>
                <option value="rating">Highest Rating</option>
                <option value="fee-asc">Hourly Fee: Low to High</option>
                <option value="fee-desc">Hourly Fee: High to Low</option>
                <option value="experience">Years of Experience</option>
              </select>
            </div>
          </div>

          {/* Active filter chips */}
          {hasActiveFilters && (
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs text-slate-400 font-medium">Active filters:</span>
              {filters.subject && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  Subject: {filters.subject}
                  <button
                    onClick={() => setFilters(p => ({ ...p, subject: '' }))}
                    className="hover:text-rose-500"
                  >
                    ×
                  </button>
                </span>
              )}
              {filters.classGrade && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
                  Class: {filters.classGrade}
                  <button
                    onClick={() => setFilters(p => ({ ...p, classGrade: '' }))}
                    className="hover:text-rose-500"
                  >
                    ×
                  </button>
                </span>
              )}
              {filters.location && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
                  Location: {filters.location}
                  <button
                    onClick={() => setFilters(p => ({ ...p, location: '' }))}
                    className="hover:text-rose-500"
                  >
                    ×
                  </button>
                </span>
              )}
              {filters.verifiedOnly && (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  Verified Only
                  <button
                    onClick={() => setFilters(p => ({ ...p, verifiedOnly: false }))}
                    className="hover:text-rose-500"
                  >
                    ×
                  </button>
                </span>
              )}
            </div>
          )}

          {/* Teachers Cards List */}
          {filteredTeachers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredTeachers.map(teacher => (
                <TeacherCard
                  key={teacher.id}
                  teacher={teacher}
                  onViewProfile={onViewTeacherProfile}
                  onRequestTuition={onRequestTuition}
                />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-800">No matching teachers found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Try loosening your filters, increasing maximum hourly budget, or searching for other subjects.
              </p>
              <button
                onClick={handleResetFilters}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold shadow-sm"
              >
                Clear All Filters
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
