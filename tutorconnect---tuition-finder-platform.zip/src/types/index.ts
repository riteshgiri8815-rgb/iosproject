export type UserRole = 'student' | 'teacher' | 'admin';

export type TeachingMode = 'online' | 'offline' | 'both';

export type VerificationStatus = 'pending' | 'verified' | 'rejected';

export type RequestStatus = 'pending' | 'accepted' | 'rejected';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
  avatarUrl?: string;
  isBlocked: boolean;
  createdAt: string;
}

export interface TeacherProfile {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  avatarUrl: string;
  qualification: string; // e.g., M.Sc Mathematics, B.Ed
  experience: number; // in years
  subjects: string[]; // e.g. ["Mathematics", "Physics", "Calculus"]
  classes: string[]; // e.g. ["Class 9-10", "Class 11-12", "IIT-JEE"]
  location: string; // e.g. "Mumbai, Maharashtra" or "South Delhi"
  city: string;
  hourlyFee: number; // in INR/currency e.g. 500
  monthlyFee: number; // e.g. 4000
  teachingMode: TeachingMode; // 'online' | 'offline' | 'both'
  availableTimings: string[]; // e.g. ["Weekday Evenings (5 PM - 8 PM)", "Weekend Mornings"]
  about: string;
  rating: number; // 4.8
  reviewCount: number;
  verificationStatus: VerificationStatus;
  verificationNotes?: string;
  degreesDocuments?: string; // name of certificate/degree submitted
  isBlocked: boolean;
  joinedDate: string;
}

export interface StudentProfile {
  id: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  avatarUrl: string;
  gradeClass: string; // e.g. "Class 10 CBSE"
  targetSubjects: string[];
  location: string;
  city: string;
  isBlocked: boolean;
  joinedDate: string;
}

export interface TuitionRequest {
  id: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  studentPhone: string;
  studentLocation: string;
  studentClass: string;
  teacherId: string;
  teacherName: string;
  teacherAvatar: string;
  subject: string;
  teachingMode: TeachingMode;
  preferredTimings: string;
  studentMessage: string;
  status: RequestStatus;
  teacherResponseNote?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface SearchFilterState {
  searchQuery: string;
  subject: string;
  classGrade: string;
  location: string;
  teachingMode: 'all' | TeachingMode;
  maxHourlyFee: number;
  verifiedOnly: boolean;
  sortBy: 'recommended' | 'rating' | 'fee-asc' | 'fee-desc' | 'experience';
}
